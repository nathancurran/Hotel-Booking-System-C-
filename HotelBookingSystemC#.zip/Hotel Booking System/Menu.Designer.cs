﻿namespace Hotel_Booking_System
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.viewBookingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewBookingsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.editBookingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.roomsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.guestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.staffToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MainMenuStrip = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuSignIn = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuSignOut = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuRegister = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuMyAccount = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.printPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuExit = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuGuest = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuFindaRoom = new System.Windows.Forms.ToolStripMenuItem();
            this.myReservationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuReception = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuCheckIn = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuCheckOut = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.guestsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuReservations = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuAdmin = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuRoomAdmin = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuReservationAdmin = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuUserAdmin = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuContactUs = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.MainMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.White;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(80, 80);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewBookingsToolStripMenuItem,
            this.roomsToolStripMenuItem,
            this.guestToolStripMenuItem,
            this.paymentToolStripMenuItem,
            this.staffToolStripMenuItem,
            this.logoutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip1.Size = new System.Drawing.Size(194, 567);
            this.menuStrip1.TabIndex = 21;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // viewBookingsToolStripMenuItem
            // 
            this.viewBookingsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewBookingsToolStripMenuItem1,
            this.editBookingsToolStripMenuItem});
            this.viewBookingsToolStripMenuItem.Image = global::Hotel_Booking_System.Properties.Resources.fsvxlzqocyhmrblzvehl1;
            this.viewBookingsToolStripMenuItem.Name = "viewBookingsToolStripMenuItem";
            this.viewBookingsToolStripMenuItem.Size = new System.Drawing.Size(181, 84);
            this.viewBookingsToolStripMenuItem.Text = "Bookings";
            this.viewBookingsToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.viewBookingsToolStripMenuItem.Click += new System.EventHandler(this.viewBookingsToolStripMenuItem_Click);
            // 
            // viewBookingsToolStripMenuItem1
            // 
            this.viewBookingsToolStripMenuItem1.Name = "viewBookingsToolStripMenuItem1";
            this.viewBookingsToolStripMenuItem1.Size = new System.Drawing.Size(218, 28);
            this.viewBookingsToolStripMenuItem1.Text = "View Bookings";
            this.viewBookingsToolStripMenuItem1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // editBookingsToolStripMenuItem
            // 
            this.editBookingsToolStripMenuItem.Name = "editBookingsToolStripMenuItem";
            this.editBookingsToolStripMenuItem.Size = new System.Drawing.Size(218, 28);
            this.editBookingsToolStripMenuItem.Text = "Edit Bookings";
            this.editBookingsToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.editBookingsToolStripMenuItem.Click += new System.EventHandler(this.editBookingsToolStripMenuItem_Click);
            // 
            // roomsToolStripMenuItem
            // 
            this.roomsToolStripMenuItem.Image = global::Hotel_Booking_System.Properties.Resources.images;
            this.roomsToolStripMenuItem.Name = "roomsToolStripMenuItem";
            this.roomsToolStripMenuItem.Size = new System.Drawing.Size(181, 84);
            this.roomsToolStripMenuItem.Text = "Rooms";
            this.roomsToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.roomsToolStripMenuItem.Click += new System.EventHandler(this.roomsToolStripMenuItem_Click);
            // 
            // guestToolStripMenuItem
            // 
            this.guestToolStripMenuItem.Image = global::Hotel_Booking_System.Properties.Resources.multiple_users_silhouette_318_49546;
            this.guestToolStripMenuItem.Name = "guestToolStripMenuItem";
            this.guestToolStripMenuItem.Size = new System.Drawing.Size(181, 84);
            this.guestToolStripMenuItem.Text = "Guest";
            this.guestToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.guestToolStripMenuItem.Click += new System.EventHandler(this.guestToolStripMenuItem_Click);
            // 
            // paymentToolStripMenuItem
            // 
            this.paymentToolStripMenuItem.Image = global::Hotel_Booking_System.Properties.Resources.credit_card_4;
            this.paymentToolStripMenuItem.Name = "paymentToolStripMenuItem";
            this.paymentToolStripMenuItem.Size = new System.Drawing.Size(181, 84);
            this.paymentToolStripMenuItem.Text = "Payment";
            this.paymentToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.paymentToolStripMenuItem.Click += new System.EventHandler(this.paymentToolStripMenuItem_Click);
            // 
            // staffToolStripMenuItem
            // 
            this.staffToolStripMenuItem.Image = global::Hotel_Booking_System.Properties.Resources._259872_200;
            this.staffToolStripMenuItem.Name = "staffToolStripMenuItem";
            this.staffToolStripMenuItem.Size = new System.Drawing.Size(181, 84);
            this.staffToolStripMenuItem.Text = "Staff";
            this.staffToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.staffToolStripMenuItem.Click += new System.EventHandler(this.staffToolStripMenuItem_Click);
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Image = global::Hotel_Booking_System.Properties.Resources._7237_200;
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(181, 84);
            this.logoutToolStripMenuItem.Text = "Logout";
            this.logoutToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // MainMenuStrip
            // 
            this.MainMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuFile,
            this.toolStripMenuGuest,
            this.toolStripMenuReception,
            this.toolStripMenuAdmin,
            this.toolStripMenuHelp});
            this.MainMenuStrip.Location = new System.Drawing.Point(194, 0);
            this.MainMenuStrip.Name = "MainMenuStrip";
            this.MainMenuStrip.ShowItemToolTips = true;
            this.MainMenuStrip.Size = new System.Drawing.Size(734, 24);
            this.MainMenuStrip.TabIndex = 145;
            // 
            // toolStripMenuFile
            // 
            this.toolStripMenuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuSignIn,
            this.toolStripMenuSignOut,
            this.toolStripMenuRegister,
            this.ToolStripMenuItem1,
            this.toolStripMenuMyAccount,
            this.toolStripSeparator8,
            this.printPreviewToolStripMenuItem,
            this.printToolStripMenuItem,
            this.toolStripSeparator2,
            this.toolStripMenuExit});
            this.toolStripMenuFile.Name = "toolStripMenuFile";
            this.toolStripMenuFile.Size = new System.Drawing.Size(37, 20);
            this.toolStripMenuFile.Text = "&File";
            // 
            // toolStripMenuSignIn
            // 
            this.toolStripMenuSignIn.Name = "toolStripMenuSignIn";
            this.toolStripMenuSignIn.Size = new System.Drawing.Size(143, 22);
            this.toolStripMenuSignIn.Text = "Sign In";
            // 
            // toolStripMenuSignOut
            // 
            this.toolStripMenuSignOut.Name = "toolStripMenuSignOut";
            this.toolStripMenuSignOut.Size = new System.Drawing.Size(143, 22);
            this.toolStripMenuSignOut.Text = "Sign Out";
            // 
            // toolStripMenuRegister
            // 
            this.toolStripMenuRegister.Name = "toolStripMenuRegister";
            this.toolStripMenuRegister.Size = new System.Drawing.Size(143, 22);
            this.toolStripMenuRegister.Text = "Register";
            // 
            // ToolStripMenuItem1
            // 
            this.ToolStripMenuItem1.Name = "ToolStripMenuItem1";
            this.ToolStripMenuItem1.Size = new System.Drawing.Size(140, 6);
            // 
            // toolStripMenuMyAccount
            // 
            this.toolStripMenuMyAccount.Name = "toolStripMenuMyAccount";
            this.toolStripMenuMyAccount.Size = new System.Drawing.Size(143, 22);
            this.toolStripMenuMyAccount.Text = "My Account";
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(140, 6);
            // 
            // printPreviewToolStripMenuItem
            // 
            this.printPreviewToolStripMenuItem.Name = "printPreviewToolStripMenuItem";
            this.printPreviewToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.printPreviewToolStripMenuItem.Text = "Print Preview";
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.printToolStripMenuItem.Text = "Print";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(140, 6);
            // 
            // toolStripMenuExit
            // 
            this.toolStripMenuExit.Name = "toolStripMenuExit";
            this.toolStripMenuExit.Size = new System.Drawing.Size(143, 22);
            this.toolStripMenuExit.Text = "&Exit";
            // 
            // toolStripMenuGuest
            // 
            this.toolStripMenuGuest.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuFindaRoom,
            this.myReservationToolStripMenuItem});
            this.toolStripMenuGuest.Name = "toolStripMenuGuest";
            this.toolStripMenuGuest.Size = new System.Drawing.Size(49, 20);
            this.toolStripMenuGuest.Text = "&Guest";
            // 
            // toolStripMenuFindaRoom
            // 
            this.toolStripMenuFindaRoom.Name = "toolStripMenuFindaRoom";
            this.toolStripMenuFindaRoom.Size = new System.Drawing.Size(160, 22);
            this.toolStripMenuFindaRoom.Text = "Find-a-Room";
            // 
            // myReservationToolStripMenuItem
            // 
            this.myReservationToolStripMenuItem.Name = "myReservationToolStripMenuItem";
            this.myReservationToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.myReservationToolStripMenuItem.Text = "My Reservations";
            // 
            // toolStripMenuReception
            // 
            this.toolStripMenuReception.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuCheckIn,
            this.toolStripMenuCheckOut,
            this.ToolStripMenuItem2,
            this.toolStripMenuItem3,
            this.guestsToolStripMenuItem,
            this.toolStripMenuReservations});
            this.toolStripMenuReception.Name = "toolStripMenuReception";
            this.toolStripMenuReception.Size = new System.Drawing.Size(72, 20);
            this.toolStripMenuReception.Text = "&Reception";
            // 
            // toolStripMenuCheckIn
            // 
            this.toolStripMenuCheckIn.Name = "toolStripMenuCheckIn";
            this.toolStripMenuCheckIn.Size = new System.Drawing.Size(140, 22);
            this.toolStripMenuCheckIn.Text = "Check-In";
            // 
            // toolStripMenuCheckOut
            // 
            this.toolStripMenuCheckOut.Name = "toolStripMenuCheckOut";
            this.toolStripMenuCheckOut.Size = new System.Drawing.Size(140, 22);
            this.toolStripMenuCheckOut.Text = "Check Out";
            // 
            // ToolStripMenuItem2
            // 
            this.ToolStripMenuItem2.Name = "ToolStripMenuItem2";
            this.ToolStripMenuItem2.Size = new System.Drawing.Size(137, 6);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(140, 22);
            this.toolStripMenuItem3.Text = "Rooms";
            // 
            // guestsToolStripMenuItem
            // 
            this.guestsToolStripMenuItem.Name = "guestsToolStripMenuItem";
            this.guestsToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
            this.guestsToolStripMenuItem.Text = "Guests";
            // 
            // toolStripMenuReservations
            // 
            this.toolStripMenuReservations.Name = "toolStripMenuReservations";
            this.toolStripMenuReservations.Size = new System.Drawing.Size(140, 22);
            this.toolStripMenuReservations.Text = "Reservations";
            // 
            // toolStripMenuAdmin
            // 
            this.toolStripMenuAdmin.Checked = true;
            this.toolStripMenuAdmin.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolStripMenuAdmin.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuRoomAdmin,
            this.toolStripMenuReservationAdmin,
            this.toolStripMenuUserAdmin});
            this.toolStripMenuAdmin.Name = "toolStripMenuAdmin";
            this.toolStripMenuAdmin.Size = new System.Drawing.Size(55, 20);
            this.toolStripMenuAdmin.Text = "&Admin";
            // 
            // toolStripMenuRoomAdmin
            // 
            this.toolStripMenuRoomAdmin.Name = "toolStripMenuRoomAdmin";
            this.toolStripMenuRoomAdmin.Size = new System.Drawing.Size(150, 22);
            this.toolStripMenuRoomAdmin.Text = "Rooms";
            // 
            // toolStripMenuReservationAdmin
            // 
            this.toolStripMenuReservationAdmin.Name = "toolStripMenuReservationAdmin";
            this.toolStripMenuReservationAdmin.Size = new System.Drawing.Size(150, 22);
            this.toolStripMenuReservationAdmin.Text = "Reservations";
            // 
            // toolStripMenuUserAdmin
            // 
            this.toolStripMenuUserAdmin.Name = "toolStripMenuUserAdmin";
            this.toolStripMenuUserAdmin.Size = new System.Drawing.Size(150, 22);
            this.toolStripMenuUserAdmin.Text = "User Accounts";
            // 
            // toolStripMenuHelp
            // 
            this.toolStripMenuHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuContactUs,
            this.toolStripSeparator1,
            this.toolStripMenuAbout});
            this.toolStripMenuHelp.Name = "toolStripMenuHelp";
            this.toolStripMenuHelp.Size = new System.Drawing.Size(44, 20);
            this.toolStripMenuHelp.Text = "&Help";
            // 
            // toolStripMenuContactUs
            // 
            this.toolStripMenuContactUs.Name = "toolStripMenuContactUs";
            this.toolStripMenuContactUs.Size = new System.Drawing.Size(132, 22);
            this.toolStripMenuContactUs.Text = "Contact Us";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(129, 6);
            // 
            // toolStripMenuAbout
            // 
            this.toolStripMenuAbout.Name = "toolStripMenuAbout";
            this.toolStripMenuAbout.Size = new System.Drawing.Size(132, 22);
            this.toolStripMenuAbout.Text = "About";
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.ClientSize = new System.Drawing.Size(928, 567);
            this.Controls.Add(this.MainMenuStrip);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Menu";
            this.Text = "Menu";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.MainMenuStrip.ResumeLayout(false);
            this.MainMenuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem viewBookingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewBookingsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem editBookingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem roomsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem guestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paymentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem staffToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        internal System.Windows.Forms.MenuStrip MainMenuStrip;
        internal System.Windows.Forms.ToolStripMenuItem toolStripMenuFile;
        internal System.Windows.Forms.ToolStripMenuItem toolStripMenuSignIn;
        internal System.Windows.Forms.ToolStripMenuItem toolStripMenuSignOut;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuRegister;
        internal System.Windows.Forms.ToolStripSeparator ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuMyAccount;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripMenuItem printPreviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        internal System.Windows.Forms.ToolStripMenuItem toolStripMenuExit;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuGuest;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuFindaRoom;
        private System.Windows.Forms.ToolStripMenuItem myReservationToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem toolStripMenuReception;
        internal System.Windows.Forms.ToolStripMenuItem toolStripMenuCheckIn;
        internal System.Windows.Forms.ToolStripMenuItem toolStripMenuCheckOut;
        internal System.Windows.Forms.ToolStripSeparator ToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem guestsToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem toolStripMenuReservations;
        internal System.Windows.Forms.ToolStripMenuItem toolStripMenuAdmin;
        internal System.Windows.Forms.ToolStripMenuItem toolStripMenuRoomAdmin;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuReservationAdmin;
        internal System.Windows.Forms.ToolStripMenuItem toolStripMenuUserAdmin;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuHelp;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuContactUs;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuAbout;


    }
}