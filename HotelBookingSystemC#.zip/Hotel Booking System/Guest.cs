﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Text.RegularExpressions;
using MetroFramework.Forms;

namespace Hotel_Booking_System
{
    public partial class Guest : MetroForm
    {
        //Establishes a connection with the SQL database
        SqlConnection cn = new SqlConnection("server=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");
        SqlCommand cmdguest = new SqlCommand();
        SqlDataAdapter daguest = new SqlDataAdapter();
        DataSet ds = new DataSet();
        SqlCommandBuilder cb;

        public Guest()
        {
            InitializeComponent();
        }

        private void control()
        {
            //Establishes the data grid's datasource
            metroGrid1.DataSource = ds;
            metroGrid1.DataMember = "Guest";
            txtGuestID.DataBindings.Add("Text", ds, "Guest.GuestID");
            txtTitle.DataBindings.Add("Text", ds, "Guest.Title");
            txtFirstName.DataBindings.Add("Text", ds, "Guest.FirstName");
            txtLastName.DataBindings.Add("Text", ds, "Guest.LastName");
            txtAddress.DataBindings.Add("Text", ds, "Guest.Address");
            txtTown.DataBindings.Add("Text", ds, "Guest.Town");
            txtPostcode.DataBindings.Add("Text", ds, "Guest.Postcode");
            txtPhoneNo.DataBindings.Add("Text", ds, "Guest.PhoneNo");
            txtEmail.DataBindings.Add("Text", ds, "Guest.Email");
        }

        private void Guest_Load(object sender, EventArgs e)
        {
            //TODO: This line of code loads data into the 'hotelBookingDBGuestDataSet.Guest' table. You can move, or remove it, as needed.
            this.guestTableAdapter.Fill(this.hotelBookingDBGuestDataSet.Guest);
            this.WindowState = FormWindowState.Maximized;

            //Loads the DataGridView
            cn.Open();
            cmdguest = new SqlCommand("Select * from Guest", cn);
            daguest = new SqlDataAdapter(cmdguest);
            daguest.Fill(ds, "Guest");
            control();
            cb = new SqlCommandBuilder(daguest);
        }

        private bool ValidateFields()
        {
            //Validates all of the data inputted into the Guest table of the SQL database before it is saved

            //Range Check for PhoneNo
            if (txtPhoneNo.Text.Length < 11)
            {
                this.txtPhoneNo.Focus();
                MessageBox.Show("Phone Number is too small.");
                return false;
            }
            else if (txtPhoneNo.Text.Length > 11)
            {
                this.txtPhoneNo.Focus();
                MessageBox.Show("Phone Number is too large.");
                return false;
            }

            //Presence Check for Phone No
            if (String.IsNullOrEmpty(this.txtPhoneNo.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtPhoneNo.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Format Check for the email
            string emailPattern = null;
            emailPattern = "^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$";
            if (!Regex.IsMatch(txtEmail.Text, emailPattern))
            {
                MessageBox.Show("Invalid Email address.");
                return false;
            }

            //Presence Check for Email
            if (String.IsNullOrEmpty(this.txtEmail.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtEmail.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Format Check for Postcode
            string postcodePattern = null;
            postcodePattern = "^(GIR 0AA)|((([A-Z-[QVX]][0-9][0-9]?)|(([A-Z-[QVX]][A-Z-[IJZ]][0-9][0-9]?)|(([A-Z-[QVX]][0-9][A-HJKSTUW])|([A-Z-[QVX]][A-Z-[IJZ]][0-9][ABEHMNPRVWXY])))) [0-9][A-Z-[CIKMOV]]{2})$";
            if (!Regex.IsMatch(txtPostcode.Text, postcodePattern))
            {
                MessageBox.Show("Invalid Post Code.");
                return false;
            }

            //Presence Check for Postcode
            if (String.IsNullOrEmpty(this.txtPostcode.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtPostcode.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Character Check for GuestID
            string numberPattern = null;
            numberPattern = "^[0-9]+$";
            if (!Regex.IsMatch(txtGuestID.Text, numberPattern))
            {
                MessageBox.Show("Invalid GuestID.");
                return false;
            }

            //Presence Check for GuestID
            if (String.IsNullOrEmpty(this.txtGuestID.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtGuestID.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Presence Check for Title
            if (String.IsNullOrEmpty(this.txtTitle.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtTitle.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Format Check for Title
            if ((txtTitle.Text != "Mr") && (txtTitle.Text != "Mrs") && (txtTitle.Text != "Dr") && (txtTitle.Text != "Ms"))
            {
                //Returns Focus to textbox.
                this.txtTitle.Focus();
                MessageBox.Show("Title must either be Mr, Mrs, Dr or Ms.");
                return false;
            }

            //Presence Check for FirstName
            if (String.IsNullOrEmpty(this.txtFirstName.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtFirstName.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Presence Check for LastName
            if (String.IsNullOrEmpty(this.txtLastName.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtLastName.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Presence Check for Address
            if (String.IsNullOrEmpty(this.txtAddress.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtAddress.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Presence Check for Town
            if (String.IsNullOrEmpty(this.txtTown.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtTown.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            else return true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidateFields() == true)
            {
                //Saves the edited record data into the Guest table of the datagrid
                bool valid = ValidateFields();
                if (valid == true)
                {
                    this.BindingContext[ds, "Guest"].EndCurrentEdit();
                    if (ds.HasChanges() == true)
                    {
                        try
                        {
                            daguest.Update(ds, "Guest");
                            MessageBox.Show("Saved.");
                            btnAdd.Enabled = true;
                        }
                        catch
                        {
                        }
                    }
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //Deletes the selected record from the Guest table of the database
            int delrow;
            delrow = this.BindingContext[ds, "Guest"].Position;
            this.BindingContext[ds, "Guest"].RemoveAt(delrow);
            try
            {
                daguest.Update(ds, "Guest");
                MessageBox.Show("Record Deleted.");
            }
            catch
            {
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //Adds a blank record into the Guest table of the datagrid
            this.BindingContext[ds, "Guest"].AddNew();
            btnAdd.Enabled = false;
        }

        private void txtSearchRecord_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (cboSearchField.SelectedIndex == 0)
                {
                    //Searchs the datagrid for records with a GuestID that complies with the search parameters
                    SqlConnection con = new SqlConnection("Data Source=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");
                    SqlDataAdapter daguest = new SqlDataAdapter("SELECT GuestID, Title, FirstName, LastName, Address, Town, Postcode, PhoneNo, Email FROM Guest where GuestID like '" + txtSearchRecord.Text + "%' ", con);
                    DataTable dt = new DataTable();
                    daguest.Fill(dt);
                    metroGrid1.DataSource = dt;
                }
                else if (cboSearchField.SelectedIndex == 1)
                {
                    //Searchs the datagrid for records with a FirstName that complies with the search parameters
                    SqlConnection con = new SqlConnection("Data Source=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");
                    SqlDataAdapter daguest = new SqlDataAdapter("SELECT GuestID, Title, FirstName, LastName, Address, Town, Postcode, PhoneNo, Email FROM Guest where Title like '" + txtSearchRecord.Text + "%' ", con);
                    DataTable dt = new DataTable();
                    daguest.Fill(dt);
                    metroGrid1.DataSource = dt;
                }
                else if (cboSearchField.SelectedIndex == 2)
                {
                    //Searchs the datagrid for records with a FirstName that complies with the search parameters
                    SqlConnection con = new SqlConnection("Data Source=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");
                    SqlDataAdapter daguest = new SqlDataAdapter("SELECT GuestID, Title, FirstName, LastName, Address, Town, Postcode, PhoneNo, Email FROM Guest where FirstName like '" + txtSearchRecord.Text + "%' ", con);
                    DataTable dt = new DataTable();
                    daguest.Fill(dt);
                    metroGrid1.DataSource = dt;
                }
                else if (cboSearchField.SelectedIndex == 3)
                {
                    //Searchs the datagrid for records with a LastName that complies with the search parameters
                    SqlConnection con = new SqlConnection("Data Source=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");
                    SqlDataAdapter daguest = new SqlDataAdapter("SELECT GuestID, Title, FirstName, LastName, Address, Town, Postcode, PhoneNo, Email FROM Guest where LastName like '" + txtSearchRecord.Text + "%' ", con);
                    DataTable dt = new DataTable();
                    daguest.Fill(dt);
                    metroGrid1.DataSource = dt;
                }
            }
            catch
            {
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            //Selects the previous record in the datagrid
            this.BindingContext[ds, "Guest"].Position--;
            metroGrid1.Update();
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            //Selects the first record in the datagrid
            this.BindingContext[ds, "Guest"].Position = 0;
            metroGrid1.Update();
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            //Selects the last record in the datagrid
            int vitri = this.BindingContext[ds, "Guest"].Count - 1;
            this.BindingContext[ds, "Guest"].Position = vitri;
            metroGrid1.Update();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            //Selects the next record in the datagrid
            this.BindingContext[ds, "Guest"].Position++;
            metroGrid1.Update();
        }
    }
}
