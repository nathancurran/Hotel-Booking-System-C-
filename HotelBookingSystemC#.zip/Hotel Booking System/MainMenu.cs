﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MetroFramework.Forms;
using System.Drawing.Printing;
using System.Globalization;
using System.Reflection;

namespace Hotel_Booking_System
{
    public partial class MainMenu : MetroForm
    {
        bool isOpen = false;
        public static string Role = null;

        public MainMenu(string role)
        {
            InitializeComponent();
            label1.Text = role;
            statusRole.Text = role;
            Role = role;
        }

        private void LogOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Log out the current user
            this.Hide();
            Login ss = new Login();
            ss.Show();
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            bmp = new Bitmap(this.Size.Width, this.Size.Height, g);
            Graphics mg = Graphics.FromImage(bmp);
            mg.CopyFromScreen(this.Location.X, this.Location.Y, 0, 0, this.Size);
            printPreviewDialog1.ShowDialog();
        }

        Bitmap bmp;

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {

            this.printDocument1.DefaultPageSettings.Landscape = true;
            this.printDocument1.PrinterSettings.DefaultPageSettings.Landscape = true;
            e.Graphics.DrawImage(bmp, 0, 0);
        }

        private void printPreviewToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void closeAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }
      
        private void MainMenu_Load(object sender, EventArgs e)
        {
            printToolStripMenuItem.Visible = false;

            //Set background colour to White
            foreach (Control ctrl in this.Controls)
            {
                if (ctrl is MdiClient)
                {
                    ctrl.BackColor = Color.White;
                }
            }
            statusUsername.Text = Login.StaffUsername;
            label2.Text = DateTime.Now.ToString("dd/MM/yyyy");

            //This limits user access depending on the Role of the user
            if (label1.Text != "Admin")
            {
                tileStaff.Enabled = false;
                tilePayment.Enabled = false;
            }
            else
            {
                tileStaff.Enabled = true;
                tilePayment.Enabled = true;
            }
        }

        private void Forms_FormClosing(object sender, FormClosingEventArgs e)
        {
            metroPanel1.Visible = true;
            tableLayoutPanel1.Visible = true;
            printToolStripMenuItem.Visible = false;
        }

        private void tileBooking_Click(object sender, EventArgs e)
        {
            //Open Bookings form
            printToolStripMenuItem.Visible = true;
            tableLayoutPanel1.Visible = false;
            metroPanel1.Visible = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "Bookings")
                {
                    isOpen = true;
                    f.Focus();
                    break;
                }
            }

            if (isOpen == false)
            {
                Bookings ss = new Bookings();
                ss.FormClosing += new FormClosingEventHandler(this.Forms_FormClosing);
                ss.MdiParent = this;
                ss.Show();
            }
            else
            {
            }
        }

        private void tileMakeBooking_Click(object sender, EventArgs e)
        {
            //Open BookRoom form
            printToolStripMenuItem.Visible = true;
            tableLayoutPanel1.Visible = false;
            metroPanel1.Visible = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "BookRoom")
                {
                    isOpen = true;
                    f.Focus();
                    break;
                }
            }

            if (isOpen == false)
            {
                BookRoom ss = new BookRoom();
                ss.FormClosing += new FormClosingEventHandler(this.Forms_FormClosing);
                ss.MdiParent = this;
                ss.Show();
            }
            else
            {
            }
        }

        private void tileRooms_Click(object sender, EventArgs e)
        {
            //Open Rooms form
            printToolStripMenuItem.Visible = true;
            tableLayoutPanel1.Visible = false;
            metroPanel1.Visible = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "Rooms")
                {
                    isOpen = true;
                    f.Focus();
                    break;
                }
            }

            if (isOpen == false)
            {
                Rooms ss = new Rooms();
                ss.FormClosing += new FormClosingEventHandler(this.Forms_FormClosing);
                ss.MdiParent = this;
                ss.Show();
            }
            else
            {
            }
        }

        private void tileGuests_Click(object sender, EventArgs e)
        {
            //Open Guest form
            printToolStripMenuItem.Visible = true;
            tableLayoutPanel1.Visible = false;
            metroPanel1.Visible = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "Guest")
                {
                    isOpen = true;
                    f.Focus();
                    break;
                }
            }

            if (isOpen == false)
            {
                Guest ss = new Guest();
                ss.FormClosing += new FormClosingEventHandler(this.Forms_FormClosing);
                ss.MdiParent = this;
                ss.Show();
            }
            else
            {
            }
        }

        private void tileStaff_Click(object sender, EventArgs e)
        {
            //Open Staff form
            printToolStripMenuItem.Visible = true;
            tableLayoutPanel1.Visible = false;
            metroPanel1.Visible = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "Staff")
                {
                    isOpen = true;
                    f.Focus();
                    break;
                }
            }

            if (isOpen == false)
            {
                Staff ss = new Staff();
                ss.FormClosing += new FormClosingEventHandler(this.Forms_FormClosing);
                ss.MdiParent = this;
                ss.Show();
            }
            else
            {
            }
        }

        private void tilePayment_Click(object sender, EventArgs e)
        {
            //Open Payment form
            printToolStripMenuItem.Visible = true;
            tableLayoutPanel1.Visible = false;
            metroPanel1.Visible = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "Payment")
                {
                    isOpen = true;
                    f.Focus();
                    break;
                }
            }

            if (isOpen == false)
            {
                Payment ss = new Payment();
                ss.FormClosing += new FormClosingEventHandler(this.Forms_FormClosing);
                ss.MdiParent = this;
                ss.Show();
            }
            else
            {
            }
        }

        private void tileCheckIn_Click(object sender, EventArgs e)
        {
            //Open CheckIn form
            printToolStripMenuItem.Visible = true;
            CheckIn CheckIn = new CheckIn();
            CheckIn.Show();
        }

        private void tileCheckOut_Click(object sender, EventArgs e)
        {
            //Open CheckOut form
            printToolStripMenuItem.Visible = true;
            CheckOut CheckOut = new CheckOut();
            CheckOut.Show();
        }

        private void tileAbout_Click(object sender, EventArgs e)
        {
            //Open AboutUs form
            printToolStripMenuItem.Visible = true;
            tableLayoutPanel1.Visible = false;
            metroPanel1.Visible = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "AboutUs")
                {
                    isOpen = true;
                    f.Focus();
                    break;
                }
            }

            if (isOpen == false)
            {
                AboutUs ss = new AboutUs();
                ss.FormClosing += new FormClosingEventHandler(this.Forms_FormClosing);
                ss.MdiParent = this;
                ss.Show();
            }
            else
            {
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Closes Application
            this.Close();
        }

    }
}
