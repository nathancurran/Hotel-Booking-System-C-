﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Text.RegularExpressions;
using MetroFramework.Forms;

namespace Hotel_Booking_System
{
    public partial class Rooms : MetroForm
    {

        //Establishes a connection with the SQL database
        SqlConnection cn = new SqlConnection("server=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");
        SqlCommand cmdrooms = new SqlCommand();
        SqlDataAdapter darooms = new SqlDataAdapter();
        DataSet ds = new DataSet();
        SqlCommandBuilder cb;
        //This holds the format for 2 decimal places
        Regex decimalRegex = new Regex(@"^[\d]*([\.\,][0-9]{2})?$");

        public Rooms()
        {
            InitializeComponent();
        }

        private void control()
        {
            //Establishes the data grid's datasource
            metroGrid1.DataSource = ds;
            metroGrid1.DataMember = "Rooms";
            txtRoomID.DataBindings.Add("Text", ds, "Rooms.RoomID");
            cboRoomType.DataBindings.Add("Text", ds, "Rooms.Type");
            txtCapacity.DataBindings.Add("Text", ds, "Rooms.Capacity");
            cboRating.DataBindings.Add("Text", ds, "Rooms.Rating");
            txtHigh.DataBindings.Add("Text", ds, "Rooms.High");
            txtMedium.DataBindings.Add("Text", ds, "Rooms.Medium");
            txtLow.DataBindings.Add("Text", ds, "Rooms.Low");
        }

        private void Rooms_Load(object sender, EventArgs e)
        {
            //TODO: This line of code loads data into the 'hotelBookingDBRoomsDataSet.Rooms' table. You can move, or remove it, as needed.
            this.roomsTableAdapter.Fill(this.hotelBookingDBRoomsDataSet.Rooms);
            this.WindowState = FormWindowState.Maximized;

            //Loads the DataGridView
            cn.Open();
            cmdrooms = new SqlCommand("Select * from Rooms", cn);
            darooms = new SqlDataAdapter(cmdrooms);
            darooms.Fill(ds, "Rooms");
            control();
            cb = new SqlCommandBuilder(darooms);

            //Disables functionality according to user privileges
            if (MainMenu.Role != "Admin")
            {
                btnAdd.Enabled = false;
                btnDelete.Enabled = false;
                btnSave.Enabled = false;
            }
        }

        private bool ValidateFields()
        {
            //Validates all of the data inputted into the Bookings table of the SQL database before it is saved

            //Character Check for RoomID
            string numberPattern = null;
            numberPattern = "^[0-9]+$";
            if (!Regex.IsMatch(txtRoomID.Text, numberPattern))
            {
                MessageBox.Show("Invalid RoomID.");
                return false;
            }

            //Presence Check for RoomID
            if (String.IsNullOrEmpty(this.txtRoomID.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtRoomID.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Presence Check for RoomType
            if (String.IsNullOrEmpty(this.cboRoomType.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.cboRoomType.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }


            //Range Check for Capacity
            if ((txtCapacity.Text != "1") && (txtCapacity.Text != "2") && (txtCapacity.Text != "3") && (txtCapacity.Text != "4"))
            {
                //Returns Focus to textbox.
                this.txtCapacity.Focus();
                MessageBox.Show("Capacity must either be 1, 2, 3 or 4.");
                return false;
            }

            //Presence Check for Capacity
            if (String.IsNullOrEmpty(this.txtCapacity.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtCapacity.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Presence Check for Rating
            if (String.IsNullOrEmpty(this.cboRating.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.cboRating.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Format Check for High
            if (decimalRegex.IsMatch(txtHigh.Text.Trim()) == false)
            {
                this.txtHigh.Focus();
                MessageBox.Show("Pricing must be inputted correctly (e.g 21.50).");
                return false;
            }

            //Presence Check for High
            if (String.IsNullOrEmpty(this.txtHigh.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtHigh.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Format Check for Medium
            if (decimalRegex.IsMatch(txtMedium.Text.Trim()) == false)
            {
                this.txtMedium.Focus();
                MessageBox.Show("Pricing must be inputted correctly (e.g 21.50).");
                return false;
            }

            //Presence Check for Medium
            if (String.IsNullOrEmpty(this.txtMedium.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtMedium.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Format Check for Low
            if (decimalRegex.IsMatch(txtLow.Text.Trim()) == false)
            {
                this.txtLow.Focus();
                MessageBox.Show("Pricing must be inputted correctly (e.g 21.50).");
                return false;
            }

            //Presence Check for Low
            if (String.IsNullOrEmpty(this.txtLow.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtLow.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }
            else return true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //Adds a blank record into the Rooms table of the datagrid
            this.BindingContext[ds, "Rooms"].AddNew();
            btnAdd.Enabled = false;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //Saves the edited record data into the Rooms table of the datagrid
            bool valid = ValidateFields();
            if (valid == true)
            {
                this.BindingContext[ds, "Rooms"].EndCurrentEdit();
                if (ds.HasChanges() == true)
                {
                    try
                    {
                        darooms.Update(ds, "Rooms");
                        MessageBox.Show("Saved.");
                        btnAdd.Enabled = true;
                    }
                    catch
                    {
                    }
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //Deletes the selected record from the Guest table of the database
            int delrow;
            delrow = this.BindingContext[ds, "Rooms"].Position;
            this.BindingContext[ds, "Rooms"].RemoveAt(delrow);
            try
            {
                darooms.Update(ds, "Rooms");
                MessageBox.Show("Record Deleted.");
            }
            catch
            {
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            //Selects the next record in the datagrid
            this.BindingContext[ds, "Rooms"].Position++;
            metroGrid1.Update();
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            //Selects the previous record in the datagrid
            this.BindingContext[ds, "Rooms"].Position--;
            metroGrid1.Update();
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            //Selects the last record in the datagrid
            int vitri = this.BindingContext[ds, "Rooms"].Count - 1;
            this.BindingContext[ds, "Rooms"].Position = vitri;
            metroGrid1.Update();
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            //Selects the first record in the datagrid
            this.BindingContext[ds, "Rooms"].Position = 0;
            metroGrid1.Update();
        }

        private void txtSearchRecord_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (cboSearchField.SelectedIndex == 0)
                {
                    //Searchs the datagrid for records with a RoomID that complies with the search parameters
                    SqlConnection con = new SqlConnection("Data Source=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");
                    SqlDataAdapter darooms = new SqlDataAdapter("SELECT RoomID, Type, Capacity, Rating, High, Medium, Low FROM Rooms where RoomID like '" + txtSearchRecord.Text + "%' ", con);
                    DataTable dt = new DataTable();
                    darooms.Fill(dt);
                    metroGrid1.DataSource = dt;
                }
                else if (cboSearchField.SelectedIndex == 1)
                {
                    //Searchs the datagrid for records with a RoomType that complies with the search parameters
                    SqlConnection con = new SqlConnection("Data Source=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");
                    SqlDataAdapter darooms = new SqlDataAdapter("SELECT RoomID, Type, Capacity, Rating, High, Medium, Low FROM Rooms where Type like '" + txtSearchRecord.Text + "%' ", con);
                    DataTable dt = new DataTable();
                    darooms.Fill(dt);
                    metroGrid1.DataSource = dt;
                }
                else if (cboSearchField.SelectedIndex == 2)
                {
                    //Searchs the datagrid for records with a Capacity that complies with the search parameters
                    SqlConnection con = new SqlConnection("Data Source=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");
                    SqlDataAdapter darooms = new SqlDataAdapter("SELECT RoomID, Type, Capacity, Rating, High, Medium, Low FROM Rooms where Capacity like '" + txtSearchRecord.Text + "%' ", con);
                    DataTable dt = new DataTable();
                    darooms.Fill(dt);
                    metroGrid1.DataSource = dt;
                }
                else if (cboSearchField.SelectedIndex == 3)
                {
                    //Searchs the datagrid for records with a RoomType that complies with the search parameters
                    SqlConnection con = new SqlConnection("Data Source=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");
                    SqlDataAdapter darooms = new SqlDataAdapter("SELECT RoomID, Type, Capacity, Rating, High, Medium, Low FROM Rooms where Rating like '" + txtSearchRecord.Text + "%' ", con);
                    DataTable dt = new DataTable();
                    darooms.Fill(dt);
                    metroGrid1.DataSource = dt;
                }
            }
            catch
            {
            }
        }
    }
}
