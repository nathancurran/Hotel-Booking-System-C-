﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Threading;
using MetroFramework.Forms;
using Salt_Password_Sample;

namespace Hotel_Booking_System
{
    public partial class Login : MetroForm
    {
        //Declare global variables
        public static string StaffUsername = null;
        public static string StaffID = null;
        public static string password = null;

        public Login()
        {
            //Create a thread for the Splashscreen to start
            Thread t = new Thread(new ThreadStart(SplashStart));
            t.Start();
            Thread.Sleep(5000);

            InitializeComponent();

            t.Abort();
        }

        public void SplashStart()
        {
            Application.Run(new Splashscreen());
        }

        private void Login_Load(object sender, EventArgs e)
        {
            //Establishes a connection with the SQL database
            SqlConnection cn = new SqlConnection("server=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");
            cn.Open();

            //Fills the Username combobox with the usernames from the Staff table
            string sql = "select * from Staff";
            SqlCommand cmd = new SqlCommand(sql, cn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            DataTable table = ds.Tables[0];
            for (int i = 0; i < table.Rows.Count; i++)
            {
                cboUsername.Items.Add(table.Rows[i][9].ToString());
            }
        }

        private int linking(string user, string pass)
        {
            //This links the inputted username and password with the one stored in the Staff table in the SQL database
            user.Trim();
            pass.Trim();
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = "Data Source=Laptop-PC\\SQLEXPRESS;" + "Initial Catalog=hotelBookingDB;" + "Integrated Security=True;";
            cn.Open();

            string sql = "select * from Staff where Username ='" + user + "' and Password ='" + pass + "' ";
            SqlCommand cmd = new SqlCommand(sql, cn);
            if (cmd.ExecuteScalar() != null)
                return 1;
            else
                return 0;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string usernameEntered = Convert.ToString(cboUsername.SelectedItem);
            using (SqlConnection con = new SqlConnection("server=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True"))
            {
                //Retrieves the StaffID from the Staff table
                using (SqlCommand command = new SqlCommand("SELECT StaffID FROM Staff WHERE Username = @Username", con))
                {
                    con.Open();
                    command.Parameters.AddWithValue("@Username", cboUsername.Text);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            StaffID = ((string.Format("{0}", reader["StaffID"])));

                        }
                    }
                }

                using (SqlCommand cmd = new SqlCommand("SELECT Username, Password FROM Staff WHERE Username=@Username", con))
                {
                    cmd.Parameters.AddWithValue("@Username", usernameEntered);

                    DataTable dt = new DataTable();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                    string Username = dt.Rows[0]["Username"].ToString();
                    string password = dt.Rows[0]["Password"].ToString();

                    //Verifies the encrypted password that is stored matches the password entered
                    bool flag = EncryptPass.VerifyHash(txtPassword.Text, "SHA512", password);

                    //If the user successfully signs in
                    if (usernameEntered == Username && flag == true)
                    {
                        //Retrieves the user's Role to be called in the Main Menu
                        SqlDataAdapter sda = new SqlDataAdapter("SELECT Role FROM Staff WHERE Username= '" + cboUsername.Text + "'", con);
                        DataTable dt2 = new System.Data.DataTable();
                        sda.Fill(dt2);

                        StaffUsername = Username;
                        this.Hide();
                        MainMenu ss = new MainMenu(dt2.Rows[0][0].ToString());
                        ss.Show();
                    }
                    else
                    {
                        MessageBox.Show("Wrong Password. Please try again.");
                        txtPassword.Text = String.Empty;
                    }
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            //Closes the application
            this.Close();
        }

        private void lbllForgotPass_Click(object sender, EventArgs e)
        {
            //Opens the Forgot Password Form
            this.Hide();
            PassReset ss = new PassReset();
            ss.Show();
        }
    }
}