﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Text.RegularExpressions;
using System.Collections;
using System.Security.Cryptography;
using System.IO;
using MetroFramework.Forms;


namespace Hotel_Booking_System
{
    public partial class Payment : MetroForm
    {
        //Declare global variables
        public static string EncryptedData;
        public static string PaymentID = null;
        public static string BookingID = null;
        public static string Type = null;
        public static string CardNumber = null;
        public static string ExpiryDate = null;
        public static string SecurityCode = null;
        public static string CardHolder = null;
        public static DateTime PaymentDate = DateTime.MinValue;
        public static string PaymentAmount = null;
        public static string FullyPaid = null;
        public static string PaymentDetails = null;
        public static string CashOrCard = null;

        public static string cipherData;
        public static byte[] cipherBytes;
        public static byte[] plainBytes;
        public static byte[] plainKey;


        //Establishes a connection with the SQL database
        SqlConnection cn = new SqlConnection("server=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");
        SqlCommand cmdpayment = new SqlCommand();
        SqlDataAdapter dapayment = new SqlDataAdapter();
        DataSet ds = new DataSet();
        SqlCommandBuilder cb;

        public Payment()
        {
            InitializeComponent();
            desObj = Rijndael.Create();
        }

        SymmetricAlgorithm desObj;

        private void control()
        {
            //Establishes the data grid's datasource
            metroGrid1.DataSource = ds;
            metroGrid1.DataMember = "Payment";
            txtPaymentID.DataBindings.Add("Text", ds, "Payment.PaymentID");
            txtBookingID.DataBindings.Add("Text", ds, "Payment.BookingID");
            cboType.DataBindings.Add("Text", ds, "Payment.Type");
            txtEncryptedData.DataBindings.Add("Text", ds, "Payment.CardNumber");
            txtSecurityCode.DataBindings.Add("Text", ds, "Payment.SecurityCode");
            txtExpiryDate.DataBindings.Add("Text", ds, "Payment.ExpiryDate");
            txtCardHolderName.DataBindings.Add("Text", ds, "Payment.CardHolder");
            txtPaymentAmount.DataBindings.Add("Text", ds, "Payment.PaymentAmount");
            txtPaymentDate.DataBindings.Add("Text", ds, "Payment.PaymentDate");
            cboFullyPaid.DataBindings.Add("Text", ds, "Payment.FullyPaid");
        }

        private void Payment_Load(object sender, EventArgs e)
        {
            /*
            //Decrypt the CardNumber data
            byte[] plainBytes2 = new byte[cipherBytes.Length];
            System.IO.MemoryStream ms1 = new System.IO.MemoryStream(cipherBytes);
            CryptoStream cs1 = new CryptoStream(ms1, desObj.CreateDecryptor(), CryptoStreamMode.Read);
            cs1.Read(plainBytes2, 0, plainBytes2.Length);
            //plainBytes2 = ms1.ToArray();
            cs1.Close();
            ms1.Close();
            string decryptedData = Encoding.ASCII.GetString(plainBytes2).TrimEnd('\0');
            txtCardNumber.Text = decryptedData;
            */

            //TODO: This line of code loads data into the 'hotelBookingDBPaymentDataSet.Payment' table. You can move, or remove it, as needed.
            this.paymentTableAdapter.Fill(this.hotelBookingDBPaymentDataSet.Payment);
            this.WindowState = FormWindowState.Maximized;

            //Loads the DataGridView
            cn.Open();
            cmdpayment = new SqlCommand("Select * from Payment", cn);
            dapayment = new SqlDataAdapter(cmdpayment);
            dapayment.Fill(ds, "Payment");
            control();
            cb = new SqlCommandBuilder(dapayment);

            rdoFullPayment.Hide();
            rdoDeposit.Hide();
            btnViewReceipt.Enabled = false;
                                  
        }

        private bool ValidateCard()
        {
            //Validates all of the card data inputted into the Payment table of the SQL database before it is saved

            //Presence Check for Security Code
            if (String.IsNullOrEmpty(this.txtSecurityCode.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtSecurityCode.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Check Security Code is valid as "999"
            var cvvCheck = new Regex(@"^\d{3}$");
            if (!cvvCheck.IsMatch(txtSecurityCode.Text))
            {
                MessageBox.Show("Invalid CVV.");
                return false;
            }

            //Presence Check for ExpiryDate
            if (String.IsNullOrEmpty(this.txtExpiryDate.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtExpiryDate.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Format Check for Expiration date number
            //Month
            int month = DateTime.Today.Month;
            if ((cboType.Text.Trim().Contains("Card") == true) && ((Convert.ToInt32(cboExpDateMonth.Text) < month)) && (Convert.ToInt32(cboExpDateYear.Text) < 18))
            {
                this.cboExpDateMonth.Focus();
                MessageBox.Show("Invalid expiration date.");
                return false;
            }

            //Presence Check for Card Number
            if (String.IsNullOrEmpty(this.txtCardNumber.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtCardNumber.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Character Check for Card Number
            string numberPattern = null;
            numberPattern = "^[0-9]+$";
            if (!Regex.IsMatch(txtCardNumber.Text, numberPattern))
            {
                MessageBox.Show("Invalid Card Number.");
                return false;
            }

            //Length Check for Card Number
            var length = txtCardNumber.Text.Length;
            if (length < 16 || length > 16)
            {
                MessageBox.Show("Invalid Card Number.");
                return false;
            }

            //Presence Check for Card Holder
            if (String.IsNullOrEmpty(this.txtCardHolderName.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtCardHolderName.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Character Check for Card Holder
            string alphaPattern = null;
            alphaPattern = "^[a-zA-Z ]+$";
            if (!Regex.IsMatch(txtCardHolderName.Text, alphaPattern))
            {
                MessageBox.Show("Invalid Card Holder.");
                return false;
            }

            else return true;
        }

        private bool ValidateFields()
        {
            //Validates all of the data inputted into the Payment table of the SQL database before it is saved

            //Presence Check for PaymentID
            if (String.IsNullOrEmpty(this.txtPaymentID.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtPaymentID.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Presence Check for BookingID
            if (String.IsNullOrEmpty(this.txtBookingID.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtBookingID.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }
                        
            //Presence Check for PaymentDate
            if (String.IsNullOrEmpty(this.txtPaymentDate.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtPaymentDate.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Presence Check for Type
            if (String.IsNullOrEmpty(this.cboType.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.cboType.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Presence Check for Payment Amount
            if (String.IsNullOrEmpty(this.txtPaymentAmount.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtPaymentAmount.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Presence Check for FullyPaid
            if (String.IsNullOrEmpty(this.cboFullyPaid.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.cboFullyPaid.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            else return true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //Adds a blank record into the Guest table of the datagrid
            this.BindingContext[ds, "Payment"].AddNew();

            rdoDeposit.Show();
            rdoFullPayment.Show();
            txtBookingID.Text = BookRoom.BookingID;
            txtPaymentDate.Text = BookRoom.bookingDate.ToString("dd-MM-yyyy");

            //Auto fill the PaymentID
            int rows = metroGrid1.RowCount;
            int newID = Convert.ToInt32(metroGrid1.Rows[rows - 3].Cells[0].Value) + 1;
            txtPaymentID.Text = Convert.ToString(newID);

            btnAdd.Enabled = false;

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //Values from the DataGridView are converted to DateTime and strings
            BookingID = txtBookingID.Text;
            Type = cboType.Text;
            PaymentDate = Convert.ToDateTime(txtPaymentDate.Text);
            PaymentAmount = Convert.ToString(txtPaymentAmount.Text);
            FullyPaid = cboFullyPaid.Text;
            PaymentID = txtPaymentID.Text;

            //Saves the edited record data into the Bookings table of the datagrid
            bool valid = ValidateFields();
            if (valid == true)
            {

                this.BindingContext[ds, "Payment"].EndCurrentEdit();
                if (ds.HasChanges() == true)
                {
                    try
                    {

                        if (cboType.Text.ToString() == "Card")
                        {
                            bool Valid = ValidateCard();
                            if (Valid == true)
                            {
                                //Declare variables
                                CardNumber = txtEncryptedData.Text;
                                SecurityCode = txtSecurityCode.Text;
                                CardHolder = txtCardHolderName.Text;
                                ExpiryDate = txtExpiryDate.Text;

                                //Add card details to string
                                CashOrCard = "Card Number: " + CardNumber + Environment.NewLine +
                                    "Expiry Date: " + ExpiryDate + Environment.NewLine +
                                    "Security Code (CVV): " + SecurityCode + Environment.NewLine +
                                    "Card Holder: " + CardHolder + Environment.NewLine;
                            }
                        }
                        else if (cboType.Text.ToString() == "Cash")
                        {
                            CashOrCard = null;
                        }

                        //Add all payment details to string
                        PaymentDetails = "Payment Details" + Environment.NewLine + "____________________________________________________________" + Environment.NewLine + Environment.NewLine +
                            "Payment Date: " + PaymentDate + Environment.NewLine +
                            "Payment ID: " + PaymentID + Environment.NewLine +
                            "Method of Payment: " + Type + Environment.NewLine +
                            "Fully Paid: " + FullyPaid + Environment.NewLine + CashOrCard +
                            "____________________________________________________________" + Environment.NewLine +
                            "Payment Amount: £" + PaymentAmount + Environment.NewLine +
                            "____________________________________________________________" + Environment.NewLine +
                            Environment.NewLine + "Processed by: " + Login.StaffUsername;

                        //Confirm payment details
                        string message = "Do you want to save these payment details?" + "\n" + "\n" + PaymentDetails;
                        DialogResult dialogResult = MessageBox.Show(message, "Confirm Payment Details", MessageBoxButtons.YesNo);
                        if (dialogResult == DialogResult.Yes)
                        {

                            dapayment.Update(ds, "Payment");
                            MessageBox.Show("Saved.");
                            btnViewReceipt.Enabled = true;
                            btnAdd.Enabled = true;
                            //Decrypt = true;

                        }
                        else if (dialogResult == DialogResult.No)
                        {

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error saving the Payment." + ex.Message);
                    }
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //Deletes the selected record from the Payment table of the database
            int delrow;
            delrow = this.BindingContext[ds, "Payment"].Position;
            this.BindingContext[ds, "Payment"].RemoveAt(delrow);
            try
            {
                dapayment.Update(ds, "Payment");
                MessageBox.Show("Record Deleted.");
            }
            catch
            {
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            //Selects the next record in the datagrid
            this.BindingContext[ds, "Payment"].Position++;
            metroGrid1.Update();
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            //Selects the previous record in the datagrid
            this.BindingContext[ds, "Payment"].Position--;
            metroGrid1.Update();
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            //Selects the last record in the datagrid
            int vitri = this.BindingContext[ds, "Payment"].Count - 1;
            this.BindingContext[ds, "Payment"].Position = vitri;
            metroGrid1.Update();
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            //Selects the first record in the datagrid
            this.BindingContext[ds, "Payment"].Position = 0;
            metroGrid1.Update();
        }

        private void cboType_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Card
            if (cboType.SelectedIndex == 1)
            {

                txtCardNumber.Enabled = true;
                txtCardHolderName.Enabled = true;
                cboExpDateMonth.Enabled = true;
                cboExpDateYear.Enabled = true;
                txtSecurityCode.Enabled = true;

            }
            //Cash
            else if (cboType.SelectedIndex == 0)
            {
                txtCardNumber.Enabled = false;
                txtCardHolderName.Enabled = false;
                cboExpDateMonth.Enabled = false;
                cboExpDateYear.Enabled = false;
                txtSecurityCode.Enabled = false;

            }
        }

        private void rdoDeposit_CheckedChanged(object sender, EventArgs e)
        {
            //Autofill input boxes
            string deposit = BookRoom.deposit.ToString();
            txtPaymentAmount.Text = deposit;
            cboFullyPaid.Text = "No";
        }

        private void rdoFullPayment_CheckedChanged(object sender, EventArgs e)
        {
            //Autofill input boxes
            string totalCost = BookRoom.totalCost.ToString();
            txtPaymentAmount.Text = totalCost;
            cboFullyPaid.Text = "Yes";
        }

        private void cboExpDateYear_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Set expiry date by joining strings toGether
            txtExpiryDate.Text = cboExpDateMonth.Text + "/" + cboExpDateYear.Text;
        }

        private void cboExpDateMonth_SelectedIndexChanged(object sender, EventArgs e)
        {

            txtExpiryDate.Text = cboExpDateMonth.Text + "/" + cboExpDateYear.Text;
        }

        private void btnViewReceipt_Click(object sender, EventArgs e)
        {
            //The Receipt form is shown if the Receipt button is clicked
            Receipt Receipt = new Receipt();
            Receipt.Show();
        }

        private void txtSearchRecord_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (cboSearchField.SelectedIndex == 0)
                {
                    //Searchs the datagrid for records with a PaymentID that complies with the search parameters
                    SqlConnection con = new SqlConnection("Data Source=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");
                    SqlDataAdapter dapayment = new SqlDataAdapter("SELECT PaymentID, BookingID, Type, CardNumber, SecurityCode, ExpiryDate, CardHolder, PaymentDate, PaymentAmount, FullyPaid FROM Payment where PaymentID like '" + txtSearchRecord.Text + "%' ", con);
                    DataTable dt = new DataTable();
                    dapayment.Fill(dt);
                    metroGrid1.DataSource = dt;
                }
                else if (cboSearchField.SelectedIndex == 1)
                {
                    //Searchs the datagrid for records with a BookingID that complies with the search parameters
                    SqlConnection con = new SqlConnection("Data Source=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");
                    SqlDataAdapter dapayment = new SqlDataAdapter("SELECT PaymentID, BookingID, Type, CardNumber, SecurityCode, ExpiryDate, CardHolder, PaymentDate, PaymentAmount, FullyPaid FROM Payment where BookingID like '" + txtSearchRecord.Text + "%' ", con);
                    DataTable dt = new DataTable();
                    dapayment.Fill(dt);
                    metroGrid1.DataSource = dt;
                }
                else if (cboSearchField.SelectedIndex == 2)
                {
                    //Searchs the datagrid for records with a GuestID that complies with the search parameters
                    SqlConnection con = new SqlConnection("Data Source=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");
                    SqlDataAdapter dapayment = new SqlDataAdapter("SELECT PaymentID, BookingID, Type, CardNumber, SecurityCode, ExpiryDate, CardHolder, PaymentDate, PaymentAmount, FullyPaid FROM Payment where CardHolder like '" + txtSearchRecord.Text + "%' ", con);
                    DataTable dt = new DataTable();
                    dapayment.Fill(dt);
                    metroGrid1.DataSource = dt;
                }
            }
            catch
            {
            }
        }

        private void txtCardNumber_TextChanged(object sender, EventArgs e)
        {
            //Encrypting the CardNumber Text
            cipherData = txtCardNumber.Text;
            plainBytes = Encoding.ASCII.GetBytes(cipherData);
            plainKey = Encoding.ASCII.GetBytes("0123456789abcdef");
            desObj.Key = plainKey;

            //Choose other appropriate modes (CBC, CFB, CTS, ECB, OFB)
            desObj.Mode = CipherMode.CBC;
            desObj.Padding = PaddingMode.PKCS7;
            System.IO.MemoryStream ms = new System.IO.MemoryStream();
            CryptoStream cs = new CryptoStream(ms, desObj.CreateEncryptor(), CryptoStreamMode.Write);
            cs.Write(plainBytes, 0, plainBytes.Length);
            cs.Close();
            cipherBytes = ms.ToArray();
            ms.Close();
            string encryptedData = Encoding.ASCII.GetString(cipherBytes);
            txtEncryptedData.Text = encryptedData;
        }
    }
}
