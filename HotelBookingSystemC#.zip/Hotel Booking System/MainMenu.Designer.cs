﻿namespace Hotel_Booking_System
{
    partial class MainMenu
    {
        ///<summary>
        ///Required designer variable.
        ///</summary>
        private System.ComponentModel.IContainer components = null;

        ///<summary>
        ///Clean up any resources being used.
        ///</summary>
        ///<param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        ///<summary>
        ///Required method for Designer support - do not modify
        ///the contents of this method with the code editor.
        ///</summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainMenu));
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusUsername = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusRole = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.fileMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.LogOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.windowsMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.closeAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.metroStyleManager1 = new MetroFramework.Components.MetroStyleManager(this.components);
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tileCheckIn = new MetroFramework.Controls.MetroTile();
            this.tileCheckOut = new MetroFramework.Controls.MetroTile();
            this.tileAbout = new MetroFramework.Controls.MetroTile();
            this.tileGuests = new MetroFramework.Controls.MetroTile();
            this.tileStaff = new MetroFramework.Controls.MetroTile();
            this.tilePayment = new MetroFramework.Controls.MetroTile();
            this.tileBooking = new MetroFramework.Controls.MetroTile();
            this.tileMakeBooking = new MetroFramework.Controls.MetroTile();
            this.tileRooms = new MetroFramework.Controls.MetroTile();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.statusStrip.SuspendLayout();
            this.panel1.SuspendLayout();
            this.menuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroStyleManager1)).BeginInit();
            this.metroPanel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel,
            this.toolStripStatusLabel3,
            this.statusUsername,
            this.statusRole});
            this.statusStrip.Location = new System.Drawing.Point(20, 587);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(907, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatusLabel.Text = "Status";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(608, 17);
            this.toolStripStatusLabel3.Spring = true;
            // 
            // statusUsername
            // 
            this.statusUsername.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.statusUsername.Name = "statusUsername";
            this.statusUsername.Size = new System.Drawing.Size(118, 17);
            this.statusUsername.Text = "toolStripStatusLabel1";
            // 
            // statusRole
            // 
            this.statusRole.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.statusRole.Name = "statusRole";
            this.statusRole.Size = new System.Drawing.Size(127, 17);
            this.statusRole.Text = "toolStripStatusLabel1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label1.Location = new System.Drawing.Point(617, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "label1";
            this.label1.Visible = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.menuStrip);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(20, 60);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(907, 22);
            this.panel1.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(844, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "label2";
            // 
            // menuStrip
            // 
            this.menuStrip.AllowMerge = false;
            this.menuStrip.BackColor = System.Drawing.Color.White;
            this.menuStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileMenu,
            this.windowsMenu,
            this.printToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.MdiWindowListItem = this.windowsMenu;
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(157, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // fileMenu
            // 
            this.fileMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.LogOutToolStripMenuItem,
            this.toolStripSeparator5,
            this.exitToolStripMenuItem});
            this.fileMenu.Name = "fileMenu";
            this.fileMenu.Size = new System.Drawing.Size(37, 20);
            this.fileMenu.Text = "&File";
            // 
            // LogOutToolStripMenuItem
            // 
            this.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem";
            this.LogOutToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
            this.LogOutToolStripMenuItem.Text = "Log &Out";
            this.LogOutToolStripMenuItem.Click += new System.EventHandler(this.LogOutToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(114, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // windowsMenu
            // 
            this.windowsMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.closeAllToolStripMenuItem,
            this.toolStripSeparator1});
            this.windowsMenu.Name = "windowsMenu";
            this.windowsMenu.Size = new System.Drawing.Size(68, 20);
            this.windowsMenu.Text = "&Windows";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(149, 6);
            // 
            // closeAllToolStripMenuItem
            // 
            this.closeAllToolStripMenuItem.Name = "closeAllToolStripMenuItem";
            this.closeAllToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.closeAllToolStripMenuItem.Text = "C&lose All";
            this.closeAllToolStripMenuItem.Click += new System.EventHandler(this.closeAllToolStripMenuItem_Click);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.printToolStripMenuItem.Text = "&Print";
            this.printToolStripMenuItem.Click += new System.EventHandler(this.printToolStripMenuItem_Click);
            // 
            // metroStyleManager1
            // 
            this.metroStyleManager1.Owner = null;
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.tableLayoutPanel1);
            this.metroPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(20, 60);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Padding = new System.Windows.Forms.Padding(100);
            this.metroPanel1.Size = new System.Drawing.Size(907, 549);
            this.metroPanel1.TabIndex = 15;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Controls.Add(this.tileCheckIn, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.tileCheckOut, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.tileAbout, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.tileGuests, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tileStaff, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tilePayment, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tileBooking, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tileMakeBooking, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.tileRooms, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(100, 100);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(707, 349);
            this.tableLayoutPanel1.TabIndex = 45;
            // 
            // tileCheckIn
            // 
            this.tileCheckIn.ActiveControl = null;
            this.tileCheckIn.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tileCheckIn.Location = new System.Drawing.Point(3, 235);
            this.tileCheckIn.Name = "tileCheckIn";
            this.tileCheckIn.Size = new System.Drawing.Size(229, 111);
            this.tileCheckIn.TabIndex = 49;
            this.tileCheckIn.Text = "CheckIn";
            this.tileCheckIn.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tileCheckIn.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tileCheckIn.UseSelectable = true;
            this.tileCheckIn.Click += new System.EventHandler(this.tileCheckIn_Click);
            // 
            // tileCheckOut
            // 
            this.tileCheckOut.ActiveControl = null;
            this.tileCheckOut.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tileCheckOut.Location = new System.Drawing.Point(238, 235);
            this.tileCheckOut.Name = "tileCheckOut";
            this.tileCheckOut.Size = new System.Drawing.Size(229, 111);
            this.tileCheckOut.TabIndex = 48;
            this.tileCheckOut.Text = "Check Out";
            this.tileCheckOut.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tileCheckOut.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tileCheckOut.UseSelectable = true;
            this.tileCheckOut.Click += new System.EventHandler(this.tileCheckOut_Click);
            // 
            // tileAbout
            // 
            this.tileAbout.ActiveControl = null;
            this.tileAbout.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tileAbout.Location = new System.Drawing.Point(473, 235);
            this.tileAbout.Name = "tileAbout";
            this.tileAbout.Size = new System.Drawing.Size(231, 111);
            this.tileAbout.TabIndex = 47;
            this.tileAbout.Text = "About";
            this.tileAbout.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tileAbout.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tileAbout.UseSelectable = true;
            this.tileAbout.Click += new System.EventHandler(this.tileAbout_Click);
            // 
            // tileGuests
            // 
            this.tileGuests.ActiveControl = null;
            this.tileGuests.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tileGuests.Location = new System.Drawing.Point(473, 119);
            this.tileGuests.Name = "tileGuests";
            this.tileGuests.Size = new System.Drawing.Size(231, 110);
            this.tileGuests.TabIndex = 46;
            this.tileGuests.Text = "Guests";
            this.tileGuests.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tileGuests.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tileGuests.UseSelectable = true;
            this.tileGuests.Click += new System.EventHandler(this.tileGuests_Click);
            // 
            // tileStaff
            // 
            this.tileStaff.ActiveControl = null;
            this.tileStaff.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tileStaff.Location = new System.Drawing.Point(238, 119);
            this.tileStaff.Name = "tileStaff";
            this.tileStaff.Size = new System.Drawing.Size(229, 110);
            this.tileStaff.TabIndex = 45;
            this.tileStaff.Text = "Staff";
            this.tileStaff.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tileStaff.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tileStaff.UseSelectable = true;
            this.tileStaff.Click += new System.EventHandler(this.tileStaff_Click);
            // 
            // tilePayment
            // 
            this.tilePayment.ActiveControl = null;
            this.tilePayment.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tilePayment.Location = new System.Drawing.Point(3, 119);
            this.tilePayment.Name = "tilePayment";
            this.tilePayment.Size = new System.Drawing.Size(229, 110);
            this.tilePayment.TabIndex = 44;
            this.tilePayment.Text = "Payment";
            this.tilePayment.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tilePayment.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tilePayment.UseSelectable = true;
            this.tilePayment.Click += new System.EventHandler(this.tilePayment_Click);
            // 
            // tileBooking
            // 
            this.tileBooking.ActiveControl = null;
            this.tileBooking.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tileBooking.Location = new System.Drawing.Point(3, 3);
            this.tileBooking.Name = "tileBooking";
            this.tileBooking.Size = new System.Drawing.Size(229, 110);
            this.tileBooking.TabIndex = 37;
            this.tileBooking.Text = "Booking";
            this.tileBooking.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tileBooking.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tileBooking.UseSelectable = true;
            this.tileBooking.Click += new System.EventHandler(this.tileBooking_Click);
            // 
            // tileMakeBooking
            // 
            this.tileMakeBooking.ActiveControl = null;
            this.tileMakeBooking.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tileMakeBooking.Location = new System.Drawing.Point(238, 3);
            this.tileMakeBooking.Name = "tileMakeBooking";
            this.tileMakeBooking.Size = new System.Drawing.Size(229, 110);
            this.tileMakeBooking.TabIndex = 38;
            this.tileMakeBooking.Text = "Make Booking";
            this.tileMakeBooking.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tileMakeBooking.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tileMakeBooking.UseSelectable = true;
            this.tileMakeBooking.Click += new System.EventHandler(this.tileMakeBooking_Click);
            // 
            // tileRooms
            // 
            this.tileRooms.ActiveControl = null;
            this.tileRooms.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tileRooms.Location = new System.Drawing.Point(473, 3);
            this.tileRooms.Name = "tileRooms";
            this.tileRooms.Size = new System.Drawing.Size(231, 110);
            this.tileRooms.TabIndex = 39;
            this.tileRooms.Text = "Rooms";
            this.tileRooms.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tileRooms.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tileRooms.UseSelectable = true;
            this.tileRooms.Click += new System.EventHandler(this.tileRooms_Click);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(947, 629);
            this.ControlBox = false;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.metroPanel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Name = "MainMenu";
            this.Style = MetroFramework.MetroColorStyle.Orange;
            this.Text = "MainMenu";
            this.TransparencyKey = System.Drawing.Color.Empty;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainMenu_Load);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroStyleManager1)).EndInit();
            this.metroPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem windowsMenu;
        private System.Windows.Forms.ToolStripMenuItem closeAllToolStripMenuItem;
        private MetroFramework.Components.MetroStyleManager metroStyleManager1;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel statusUsername;
        private System.Windows.Forms.ToolStripStatusLabel statusRole;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private MetroFramework.Controls.MetroTile tileCheckIn;
        private MetroFramework.Controls.MetroTile tileCheckOut;
        private MetroFramework.Controls.MetroTile tileAbout;
        private MetroFramework.Controls.MetroTile tileGuests;
        private MetroFramework.Controls.MetroTile tileStaff;
        private MetroFramework.Controls.MetroTile tilePayment;
        private MetroFramework.Controls.MetroTile tileBooking;
        private MetroFramework.Controls.MetroTile tileMakeBooking;
        private MetroFramework.Controls.MetroTile tileRooms;
        private System.Windows.Forms.ToolStripMenuItem fileMenu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem LogOutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Drawing.Printing.PrintDocument printDocument1;
        public System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    }
}



