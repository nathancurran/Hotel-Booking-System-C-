﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Text.RegularExpressions;
using System.Collections;
using MetroFramework.Forms;

namespace Hotel_Booking_System
{
    public partial class Bookings : MetroForm
    {
        //Establishes a connection with the SQL database
        SqlConnection cn = new SqlConnection("server=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");
        SqlCommand cmdbookings = new SqlCommand();
        SqlDataAdapter dabookings = new SqlDataAdapter();
        DataSet ds = new DataSet();
        SqlCommandBuilder cb;
        //Holds the regular expression format for 2 decimal places
        Regex decimalRegex = new Regex(@"^[\d]*([\.\,][0-9]{2})?$");

        public Bookings()
        {
            InitializeComponent();
        }

        private void control()
        {
            //Establishes the data grid's datasource
            metroGrid1.DataSource = ds;
            metroGrid1.DataMember = "Booking";
            txtBookingID.DataBindings.Add("Text", ds, "Booking.BookingID");
            txtRoomID.DataBindings.Add("Text", ds, "Booking.RoomID");
            txtGuestID.DataBindings.Add("Text", ds, "Booking.GuestID");
            txtStaffID.DataBindings.Add("Text", ds, "Booking.StaffID");
            txtStartDate.DataBindings.Add("Text", ds, "Booking.StartDate");
            txtEndDate.DataBindings.Add("Text", ds, "Booking.EndDate");
            txtBookedDate.DataBindings.Add("Text", ds, "Booking.BookedDate");
            txtTotalPrice.DataBindings.Add("Text", ds, "Booking.TotalPrice");
            txtDeposit.DataBindings.Add("Text", ds, "Booking.Deposit");
        }

        private void Bookings_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'hotelBookingDBBookingDataSet.Booking' table. You can move, or remove it, as needed.
            this.bookingTableAdapter.Fill(this.hotelBookingDBBookingDataSet.Booking);
            
            //TODO: This line of code loads data into the 'hotelBookingDBBookingDataSet.Booking' table. You can move, or remove it, as needed.
            this.bookingTableAdapter.Fill(this.hotelBookingDBBookingDataSet.Booking);
            this.WindowState = FormWindowState.Maximized;

            //Loads the DataGridView
            cn.Open();
            cmdbookings = new SqlCommand("Select * from Booking", cn);
            dabookings = new SqlDataAdapter(cmdbookings);
            dabookings.Fill(ds, "Booking");
            control();
            cb = new SqlCommandBuilder(dabookings);
        }


        private bool ValidateFields()
        {
            //Validates all of the data inputted into the Bookings table of the SQL database before it is saved

            //Character Check for BookingID
            string numberPattern = null;
            numberPattern = "^[0-9]+$";
            if (!Regex.IsMatch(txtBookingID.Text, numberPattern))
            {
                MessageBox.Show("Invalid BookingID.");
                return false;
            }

            //Presence Check for BookingID
            if (String.IsNullOrEmpty(this.txtBookingID.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtBookingID.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Character Check for GuestID        
            if (!Regex.IsMatch(txtGuestID.Text, numberPattern))
            {
                MessageBox.Show("Invalid GuestID.");
                return false;
            }

            //Presence Check for GuestID
            if (String.IsNullOrEmpty(this.txtGuestID.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtGuestID.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Character Check for RoomID        
            if (!Regex.IsMatch(txtRoomID.Text, numberPattern))
            {
                MessageBox.Show("Invalid RoomID.");
                return false;
            }

            //Presence Check for RoomID
            if (String.IsNullOrEmpty(this.txtRoomID.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtRoomID.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Character Check for StaffID
            if (!Regex.IsMatch(txtStaffID.Text, numberPattern))
            {
                MessageBox.Show("Invalid StaffID.");
                return false;
            }

            //Presence Check for StaffID
            if (String.IsNullOrEmpty(this.txtStaffID.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtStaffID.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Presence Check for StartDate
            if (String.IsNullOrEmpty(this.txtStartDate.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtStartDate.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Presence Check for EndDate
            if (String.IsNullOrEmpty(this.txtEndDate.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtEndDate.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Presence Check for BookedDate
            if (String.IsNullOrEmpty(this.txtBookedDate.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtBookedDate.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Format Check for TotalPrice
            if (decimalRegex.IsMatch(txtTotalPrice.Text.Trim()) == false)
            {
                this.txtTotalPrice.Focus();
                MessageBox.Show("Pricing must be inputted correctly (e.g 21.50).");
                return false;
            }

            //Presence Check for TotalPrice
            if (String.IsNullOrEmpty(this.txtTotalPrice.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtTotalPrice.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            //Format Check for Deposit
            if (decimalRegex.IsMatch(txtDeposit.Text.Trim()) == false)
            {
                this.txtDeposit.Focus();
                MessageBox.Show("Pricing must be inputted correctly (e.g 21.50).");
                return false;
            }

            //Presence Check for Deposit
            if (String.IsNullOrEmpty(this.txtDeposit.Text.Trim()))
            {
                //Returns Focus to textbox.
                this.txtDeposit.Focus();
                MessageBox.Show("One or more textboxes are empty.");
                return false;
            }

            else return true;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //Deletes the selected record from the Bookings table of the database
            int delrow;
            delrow = this.BindingContext[ds, "Booking"].Position;
            this.BindingContext[ds, "Booking"].RemoveAt(delrow);
            try
            {
                dabookings.Update(ds, "Booking");
                MessageBox.Show("Record Deleted.");
            }
            catch
            {
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //Saves the edited record into the Bookings table of the database
            bool valid = ValidateFields();
            if (valid == true)
            {
                this.BindingContext[ds, "Booking"].EndCurrentEdit();
                if (valid == true)
                {
                    this.BindingContext[ds, "Booking"].EndCurrentEdit();
                    if (ds.HasChanges() == true)
                    {
                        try
                        {
                            dabookings.Update(ds, "Booking");
                            MessageBox.Show("Saved.");
                        }
                        catch
                        {
                        }
                    }
                }
            }
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            //Selects the first record in the datagrid
            this.BindingContext[ds, "Booking"].Position = 0;
            metroGrid1.Update();
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            //Selects the last record in the datagrid
            int vitri = this.BindingContext[ds, "Booking"].Count - 1;
            this.BindingContext[ds, "Booking"].Position = vitri;
            metroGrid1.Update();
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            //Selects the previous record in the datagrid
            this.BindingContext[ds, "Booking"].Position--;
            metroGrid1.Update();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            //Selects the next record in the datagrid
            this.BindingContext[ds, "Booking"].Position++;
            metroGrid1.Update();
        }

        private void txtSearchRecord_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (cboSearchField.SelectedIndex == 0)
                {
                    //Searchs the datagrid for records with a BookingID that complies with the search parameters
                    SqlConnection con = new SqlConnection("Data Source=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");
                    SqlDataAdapter dabookings = new SqlDataAdapter("SELECT BookingID, RoomID, GuestID, StaffID, StartDate, EndDate, BookedDate, TotalPrice, Deposit, CheckIn, CheckOut FROM Booking where BookingID like '" + txtSearchRecord.Text + "%' ", con);
                    DataTable dt = new DataTable();
                    dabookings.Fill(dt);
                    metroGrid1.DataSource = dt;
                }
                else if (cboSearchField.SelectedIndex == 1)
                {
                    //Searchs the datagrid for records with a RoomID that complies with the search parameters
                    SqlConnection con = new SqlConnection("Data Source=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");
                    SqlDataAdapter dabookings = new SqlDataAdapter("SELECT BookingID, RoomID, GuestID, StaffID, StartDate, EndDate, BookedDate, TotalPrice, Deposit, CheckIn, CheckOut FROM Booking where RoomID like '" + txtSearchRecord.Text + "%' ", con);
                    DataTable dt = new DataTable();
                    dabookings.Fill(dt);
                    metroGrid1.DataSource = dt;
                }
                else if (cboSearchField.SelectedIndex == 2)
                {
                    //Searchs the datagrid for records with a GuestID that complies with the search parameters
                    SqlConnection con = new SqlConnection("Data Source=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");
                    SqlDataAdapter dabookings = new SqlDataAdapter("SELECT BookingID, RoomID, GuestID, StaffID, StartDate, EndDate, BookedDate, TotalPrice, Deposit, CheckIn, CheckOut FROM Booking where GuestID like '" + txtSearchRecord.Text + "%' ", con);
                    DataTable dt = new DataTable();
                    dabookings.Fill(dt);
                    metroGrid1.DataSource = dt;
                }
                else if (cboSearchField.SelectedIndex == 3)
                {
                    //Searchs the datagrid for records with a GuestID that complies with the search parameters
                    SqlConnection con = new SqlConnection("Data Source=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");
                    SqlDataAdapter dabookings = new SqlDataAdapter("SELECT BookingID, RoomID, GuestID, StaffID, StartDate, EndDate, BookedDate, TotalPrice, Deposit, CheckIn, CheckOut FROM Booking where StaffID like '" + txtSearchRecord.Text + "%' ", con);
                    DataTable dt = new DataTable();
                    dabookings.Fill(dt);
                    metroGrid1.DataSource = dt;
                }
            }
            catch
            {
            }
        }
    }
}
