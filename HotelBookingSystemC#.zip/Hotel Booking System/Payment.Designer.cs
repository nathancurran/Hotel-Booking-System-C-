﻿namespace Hotel_Booking_System
{
    partial class Payment
    {
        ///<summary>
        ///Required designer variable.
        ///</summary>
        private System.ComponentModel.IContainer components = null;

        ///<summary>
        ///Clean up any resources being used.
        ///</summary>
        ///<param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        ///<summary>
        ///Required method for Designer support - do not modify
        ///the contents of this method with the code editor.
        ///</summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Payment));
            this.label5 = new System.Windows.Forms.Label();
            this.cboType = new MetroFramework.Controls.MetroComboBox();
            this.txtPaymentID = new MetroFramework.Controls.MetroTextBox();
            this.txtPaymentDate = new MetroFramework.Controls.MetroTextBox();
            this.txtBookingID = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.rdoDeposit = new MetroFramework.Controls.MetroRadioButton();
            this.rdoFullPayment = new MetroFramework.Controls.MetroRadioButton();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.txtPaymentAmount = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.cboFullyPaid = new MetroFramework.Controls.MetroComboBox();
            this.txtSearchRecord = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.cboSearchField = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.btnAdd = new MetroFramework.Controls.MetroButton();
            this.btnNext = new MetroFramework.Controls.MetroButton();
            this.btnPrevious = new MetroFramework.Controls.MetroButton();
            this.btnLast = new MetroFramework.Controls.MetroButton();
            this.btnFirst = new MetroFramework.Controls.MetroButton();
            this.btnSave = new MetroFramework.Controls.MetroButton();
            this.btnDelete = new MetroFramework.Controls.MetroButton();
            this.metroGrid1 = new MetroFramework.Controls.MetroGrid();
            this.paymentIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bookingIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.typeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cardNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.securityCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.expiryDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cardHolderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paymentDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paymentAmountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fullyPaidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paymentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.hotelBookingDBPaymentDataSet = new Hotel_Booking_System.HotelBookingDBPaymentDataSet();
            this.btnViewReceipt = new MetroFramework.Controls.MetroButton();
            this.txtCardNumber = new MetroFramework.Controls.MetroTextBox();
            this.cboExpDateMonth = new MetroFramework.Controls.MetroComboBox();
            this.cboExpDateYear = new MetroFramework.Controls.MetroComboBox();
            this.txtExpiryDate = new MetroFramework.Controls.MetroTextBox();
            this.txtSecurityCode = new MetroFramework.Controls.MetroTextBox();
            this.txtCardHolderName = new MetroFramework.Controls.MetroTextBox();
            this.paymentTableAdapter = new Hotel_Booking_System.HotelBookingDBPaymentDataSetTableAdapters.PaymentTableAdapter();
            this.txtEncryptedData = new MetroFramework.Controls.MetroTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.paymentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotelBookingDBPaymentDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label5.Location = new System.Drawing.Point(251, 238);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(13, 20);
            this.label5.TabIndex = 194;
            this.label5.Text = "/";
            // 
            // cboType
            // 
            this.cboType.FormattingEnabled = true;
            this.cboType.ItemHeight = 23;
            this.cboType.Items.AddRange(new object[] {
            "Cash",
            "Card"});
            this.cboType.Location = new System.Drawing.Point(525, 55);
            this.cboType.Name = "cboType";
            this.cboType.Size = new System.Drawing.Size(235, 29);
            this.cboType.TabIndex = 217;
            this.cboType.UseSelectable = true;
            this.cboType.SelectedIndexChanged += new System.EventHandler(this.cboType_SelectedIndexChanged);
            // 
            // txtPaymentID
            // 
            // 
            // 
            // 
            this.txtPaymentID.CustomButton.Image = null;
            this.txtPaymentID.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtPaymentID.CustomButton.Name = "";
            this.txtPaymentID.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtPaymentID.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtPaymentID.CustomButton.TabIndex = 1;
            this.txtPaymentID.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtPaymentID.CustomButton.UseSelectable = true;
            this.txtPaymentID.CustomButton.Visible = false;
            this.txtPaymentID.Lines = new string[0];
            this.txtPaymentID.Location = new System.Drawing.Point(142, 57);
            this.txtPaymentID.MaxLength = 32767;
            this.txtPaymentID.Name = "txtPaymentID";
            this.txtPaymentID.PasswordChar = '\0';
            this.txtPaymentID.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPaymentID.SelectedText = "";
            this.txtPaymentID.SelectionLength = 0;
            this.txtPaymentID.SelectionStart = 0;
            this.txtPaymentID.ShortcutsEnabled = true;
            this.txtPaymentID.Size = new System.Drawing.Size(235, 23);
            this.txtPaymentID.TabIndex = 212;
            this.txtPaymentID.UseSelectable = true;
            this.txtPaymentID.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtPaymentID.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtPaymentDate
            // 
            // 
            // 
            // 
            this.txtPaymentDate.CustomButton.Image = null;
            this.txtPaymentDate.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtPaymentDate.CustomButton.Name = "";
            this.txtPaymentDate.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtPaymentDate.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtPaymentDate.CustomButton.TabIndex = 1;
            this.txtPaymentDate.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtPaymentDate.CustomButton.UseSelectable = true;
            this.txtPaymentDate.CustomButton.Visible = false;
            this.txtPaymentDate.Lines = new string[0];
            this.txtPaymentDate.Location = new System.Drawing.Point(142, 115);
            this.txtPaymentDate.MaxLength = 32767;
            this.txtPaymentDate.Name = "txtPaymentDate";
            this.txtPaymentDate.PasswordChar = '\0';
            this.txtPaymentDate.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPaymentDate.SelectedText = "";
            this.txtPaymentDate.SelectionLength = 0;
            this.txtPaymentDate.SelectionStart = 0;
            this.txtPaymentDate.ShortcutsEnabled = true;
            this.txtPaymentDate.Size = new System.Drawing.Size(235, 23);
            this.txtPaymentDate.TabIndex = 211;
            this.txtPaymentDate.UseSelectable = true;
            this.txtPaymentDate.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtPaymentDate.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtBookingID
            // 
            // 
            // 
            // 
            this.txtBookingID.CustomButton.Image = null;
            this.txtBookingID.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtBookingID.CustomButton.Name = "";
            this.txtBookingID.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtBookingID.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtBookingID.CustomButton.TabIndex = 1;
            this.txtBookingID.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtBookingID.CustomButton.UseSelectable = true;
            this.txtBookingID.CustomButton.Visible = false;
            this.txtBookingID.Lines = new string[0];
            this.txtBookingID.Location = new System.Drawing.Point(142, 86);
            this.txtBookingID.MaxLength = 32767;
            this.txtBookingID.Name = "txtBookingID";
            this.txtBookingID.PasswordChar = '\0';
            this.txtBookingID.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBookingID.SelectedText = "";
            this.txtBookingID.SelectionLength = 0;
            this.txtBookingID.SelectionStart = 0;
            this.txtBookingID.ShortcutsEnabled = true;
            this.txtBookingID.Size = new System.Drawing.Size(235, 23);
            this.txtBookingID.TabIndex = 210;
            this.txtBookingID.UseSelectable = true;
            this.txtBookingID.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtBookingID.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.Location = new System.Drawing.Point(403, 57);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(113, 19);
            this.metroLabel14.TabIndex = 214;
            this.metroLabel14.Text = "Payment Method:";
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.Location = new System.Drawing.Point(20, 119);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(94, 19);
            this.metroLabel10.TabIndex = 216;
            this.metroLabel10.Text = "Payment Date:";
            // 
            // metroLabel13
            // 
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.Location = new System.Drawing.Point(23, 60);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(75, 19);
            this.metroLabel13.TabIndex = 215;
            this.metroLabel13.Text = "PaymentID:";
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(23, 87);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(72, 19);
            this.metroLabel9.TabIndex = 213;
            this.metroLabel9.Text = "BookingID:";
            // 
            // rdoDeposit
            // 
            this.rdoDeposit.AutoSize = true;
            this.rdoDeposit.Location = new System.Drawing.Point(160, 144);
            this.rdoDeposit.Name = "rdoDeposit";
            this.rdoDeposit.Size = new System.Drawing.Size(63, 15);
            this.rdoDeposit.TabIndex = 218;
            this.rdoDeposit.Text = "Deposit";
            this.rdoDeposit.UseSelectable = true;
            this.rdoDeposit.CheckedChanged += new System.EventHandler(this.rdoDeposit_CheckedChanged);
            // 
            // rdoFullPayment
            // 
            this.rdoFullPayment.AutoSize = true;
            this.rdoFullPayment.Location = new System.Drawing.Point(248, 144);
            this.rdoFullPayment.Name = "rdoFullPayment";
            this.rdoFullPayment.Size = new System.Drawing.Size(92, 15);
            this.rdoFullPayment.TabIndex = 219;
            this.rdoFullPayment.Text = "Full Payment";
            this.rdoFullPayment.UseSelectable = true;
            this.rdoFullPayment.CheckedChanged += new System.EventHandler(this.rdoFullPayment_CheckedChanged);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(403, 94);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(114, 19);
            this.metroLabel1.TabIndex = 216;
            this.metroLabel1.Text = "Payment Amount:";
            // 
            // txtPaymentAmount
            // 
            // 
            // 
            // 
            this.txtPaymentAmount.CustomButton.Image = null;
            this.txtPaymentAmount.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtPaymentAmount.CustomButton.Name = "";
            this.txtPaymentAmount.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtPaymentAmount.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtPaymentAmount.CustomButton.TabIndex = 1;
            this.txtPaymentAmount.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtPaymentAmount.CustomButton.UseSelectable = true;
            this.txtPaymentAmount.CustomButton.Visible = false;
            this.txtPaymentAmount.Lines = new string[0];
            this.txtPaymentAmount.Location = new System.Drawing.Point(525, 90);
            this.txtPaymentAmount.MaxLength = 32767;
            this.txtPaymentAmount.Name = "txtPaymentAmount";
            this.txtPaymentAmount.PasswordChar = '\0';
            this.txtPaymentAmount.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPaymentAmount.SelectedText = "";
            this.txtPaymentAmount.SelectionLength = 0;
            this.txtPaymentAmount.SelectionStart = 0;
            this.txtPaymentAmount.ShortcutsEnabled = true;
            this.txtPaymentAmount.Size = new System.Drawing.Size(235, 23);
            this.txtPaymentAmount.TabIndex = 211;
            this.txtPaymentAmount.UseSelectable = true;
            this.txtPaymentAmount.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtPaymentAmount.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(403, 121);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(68, 19);
            this.metroLabel2.TabIndex = 214;
            this.metroLabel2.Text = "Fully Paid:";
            // 
            // cboFullyPaid
            // 
            this.cboFullyPaid.FormattingEnabled = true;
            this.cboFullyPaid.ItemHeight = 23;
            this.cboFullyPaid.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cboFullyPaid.Location = new System.Drawing.Point(525, 119);
            this.cboFullyPaid.Name = "cboFullyPaid";
            this.cboFullyPaid.Size = new System.Drawing.Size(80, 29);
            this.cboFullyPaid.TabIndex = 217;
            this.cboFullyPaid.UseSelectable = true;
            // 
            // txtSearchRecord
            // 
            // 
            // 
            // 
            this.txtSearchRecord.CustomButton.Image = null;
            this.txtSearchRecord.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtSearchRecord.CustomButton.Name = "";
            this.txtSearchRecord.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtSearchRecord.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtSearchRecord.CustomButton.TabIndex = 1;
            this.txtSearchRecord.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtSearchRecord.CustomButton.UseSelectable = true;
            this.txtSearchRecord.CustomButton.Visible = false;
            this.txtSearchRecord.Lines = new string[0];
            this.txtSearchRecord.Location = new System.Drawing.Point(525, 273);
            this.txtSearchRecord.MaxLength = 32767;
            this.txtSearchRecord.Name = "txtSearchRecord";
            this.txtSearchRecord.PasswordChar = '\0';
            this.txtSearchRecord.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSearchRecord.SelectedText = "";
            this.txtSearchRecord.SelectionLength = 0;
            this.txtSearchRecord.SelectionStart = 0;
            this.txtSearchRecord.ShortcutsEnabled = true;
            this.txtSearchRecord.Size = new System.Drawing.Size(235, 23);
            this.txtSearchRecord.TabIndex = 221;
            this.txtSearchRecord.UseSelectable = true;
            this.txtSearchRecord.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtSearchRecord.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtSearchRecord.TextChanged += new System.EventHandler(this.txtSearchRecord_TextChanged);
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel11.Location = new System.Drawing.Point(524, 245);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(121, 25);
            this.metroLabel11.TabIndex = 222;
            this.metroLabel11.Text = "Search Record";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel3.Location = new System.Drawing.Point(525, 181);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(103, 25);
            this.metroLabel3.TabIndex = 223;
            this.metroLabel3.Text = "Search Field";
            // 
            // cboSearchField
            // 
            this.cboSearchField.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboSearchField.FormattingEnabled = true;
            this.cboSearchField.ItemHeight = 23;
            this.cboSearchField.Items.AddRange(new object[] {
            "PaymentID",
            "BookingID",
            "CardHolder"});
            this.cboSearchField.Location = new System.Drawing.Point(525, 210);
            this.cboSearchField.Name = "cboSearchField";
            this.cboSearchField.Size = new System.Drawing.Size(234, 29);
            this.cboSearchField.TabIndex = 220;
            this.cboSearchField.UseSelectable = true;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.Location = new System.Drawing.Point(43, 173);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(83, 19);
            this.metroLabel4.TabIndex = 216;
            this.metroLabel4.Text = "Card Details";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(20, 210);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(94, 19);
            this.metroLabel5.TabIndex = 216;
            this.metroLabel5.Text = "Card Number:";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(23, 239);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(78, 19);
            this.metroLabel6.TabIndex = 216;
            this.metroLabel6.Text = "Expiry Date:";
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(20, 274);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(130, 19);
            this.metroLabel7.TabIndex = 216;
            this.metroLabel7.Text = "Security Code (CVV):";
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(25, 306);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(125, 19);
            this.metroLabel8.TabIndex = 216;
            this.metroLabel8.Text = "Card Holder Name:";
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(20, 60);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(968, 570);
            this.shapeContainer1.TabIndex = 224;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 5;
            this.lineShape1.X2 = 410;
            this.lineShape1.Y1 = 133;
            this.lineShape1.Y2 = 133;
            // 
            // btnAdd
            // 
            this.btnAdd.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btnAdd.Location = new System.Drawing.Point(19, 338);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(91, 32);
            this.btnAdd.TabIndex = 225;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseSelectable = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(867, 338);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(58, 32);
            this.btnNext.TabIndex = 230;
            this.btnNext.Text = ">";
            this.btnNext.UseSelectable = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Location = new System.Drawing.Point(803, 338);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(58, 32);
            this.btnPrevious.TabIndex = 229;
            this.btnPrevious.Text = "<";
            this.btnPrevious.UseSelectable = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnLast
            // 
            this.btnLast.Location = new System.Drawing.Point(931, 338);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(58, 32);
            this.btnLast.TabIndex = 231;
            this.btnLast.Text = ">>";
            this.btnLast.UseSelectable = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // btnFirst
            // 
            this.btnFirst.Location = new System.Drawing.Point(739, 338);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(58, 32);
            this.btnFirst.TabIndex = 228;
            this.btnFirst.Text = "<<";
            this.btnFirst.UseSelectable = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // btnSave
            // 
            this.btnSave.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btnSave.Location = new System.Drawing.Point(213, 338);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(91, 32);
            this.btnSave.TabIndex = 227;
            this.btnSave.Text = "Save";
            this.btnSave.UseSelectable = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btnDelete.Location = new System.Drawing.Point(116, 338);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(91, 32);
            this.btnDelete.TabIndex = 226;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseSelectable = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // metroGrid1
            // 
            this.metroGrid1.AllowUserToResizeRows = false;
            this.metroGrid1.AutoGenerateColumns = false;
            this.metroGrid1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.metroGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.metroGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.paymentIDDataGridViewTextBoxColumn,
            this.bookingIDDataGridViewTextBoxColumn,
            this.typeDataGridViewTextBoxColumn,
            this.cardNumberDataGridViewTextBoxColumn,
            this.securityCodeDataGridViewTextBoxColumn,
            this.expiryDateDataGridViewTextBoxColumn,
            this.cardHolderDataGridViewTextBoxColumn,
            this.paymentDateDataGridViewTextBoxColumn,
            this.paymentAmountDataGridViewTextBoxColumn,
            this.fullyPaidDataGridViewTextBoxColumn});
            this.metroGrid1.DataSource = this.paymentBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid1.DefaultCellStyle = dataGridViewCellStyle2;
            this.metroGrid1.EnableHeadersVisualStyles = false;
            this.metroGrid1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid1.Location = new System.Drawing.Point(20, 376);
            this.metroGrid1.Name = "metroGrid1";
            this.metroGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.metroGrid1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid1.Size = new System.Drawing.Size(965, 251);
            this.metroGrid1.TabIndex = 232;
            // 
            // paymentIDDataGridViewTextBoxColumn
            // 
            this.paymentIDDataGridViewTextBoxColumn.DataPropertyName = "PaymentID";
            this.paymentIDDataGridViewTextBoxColumn.HeaderText = "PaymentID";
            this.paymentIDDataGridViewTextBoxColumn.Name = "paymentIDDataGridViewTextBoxColumn";
            // 
            // bookingIDDataGridViewTextBoxColumn
            // 
            this.bookingIDDataGridViewTextBoxColumn.DataPropertyName = "BookingID";
            this.bookingIDDataGridViewTextBoxColumn.HeaderText = "BookingID";
            this.bookingIDDataGridViewTextBoxColumn.Name = "bookingIDDataGridViewTextBoxColumn";
            // 
            // typeDataGridViewTextBoxColumn
            // 
            this.typeDataGridViewTextBoxColumn.DataPropertyName = "Type";
            this.typeDataGridViewTextBoxColumn.HeaderText = "Type";
            this.typeDataGridViewTextBoxColumn.Name = "typeDataGridViewTextBoxColumn";
            // 
            // cardNumberDataGridViewTextBoxColumn
            // 
            this.cardNumberDataGridViewTextBoxColumn.DataPropertyName = "CardNumber";
            this.cardNumberDataGridViewTextBoxColumn.HeaderText = "CardNumber";
            this.cardNumberDataGridViewTextBoxColumn.Name = "cardNumberDataGridViewTextBoxColumn";
            // 
            // securityCodeDataGridViewTextBoxColumn
            // 
            this.securityCodeDataGridViewTextBoxColumn.DataPropertyName = "SecurityCode";
            this.securityCodeDataGridViewTextBoxColumn.HeaderText = "SecurityCode";
            this.securityCodeDataGridViewTextBoxColumn.Name = "securityCodeDataGridViewTextBoxColumn";
            // 
            // expiryDateDataGridViewTextBoxColumn
            // 
            this.expiryDateDataGridViewTextBoxColumn.DataPropertyName = "ExpiryDate";
            this.expiryDateDataGridViewTextBoxColumn.HeaderText = "ExpiryDate";
            this.expiryDateDataGridViewTextBoxColumn.Name = "expiryDateDataGridViewTextBoxColumn";
            // 
            // cardHolderDataGridViewTextBoxColumn
            // 
            this.cardHolderDataGridViewTextBoxColumn.DataPropertyName = "CardHolder";
            this.cardHolderDataGridViewTextBoxColumn.HeaderText = "CardHolder";
            this.cardHolderDataGridViewTextBoxColumn.Name = "cardHolderDataGridViewTextBoxColumn";
            // 
            // paymentDateDataGridViewTextBoxColumn
            // 
            this.paymentDateDataGridViewTextBoxColumn.DataPropertyName = "PaymentDate";
            this.paymentDateDataGridViewTextBoxColumn.HeaderText = "PaymentDate";
            this.paymentDateDataGridViewTextBoxColumn.Name = "paymentDateDataGridViewTextBoxColumn";
            // 
            // paymentAmountDataGridViewTextBoxColumn
            // 
            this.paymentAmountDataGridViewTextBoxColumn.DataPropertyName = "PaymentAmount";
            this.paymentAmountDataGridViewTextBoxColumn.HeaderText = "PaymentAmount";
            this.paymentAmountDataGridViewTextBoxColumn.Name = "paymentAmountDataGridViewTextBoxColumn";
            // 
            // fullyPaidDataGridViewTextBoxColumn
            // 
            this.fullyPaidDataGridViewTextBoxColumn.DataPropertyName = "FullyPaid";
            this.fullyPaidDataGridViewTextBoxColumn.HeaderText = "FullyPaid";
            this.fullyPaidDataGridViewTextBoxColumn.Name = "fullyPaidDataGridViewTextBoxColumn";
            // 
            // paymentBindingSource
            // 
            this.paymentBindingSource.DataMember = "Payment";
            this.paymentBindingSource.DataSource = this.hotelBookingDBPaymentDataSet;
            // 
            // hotelBookingDBPaymentDataSet
            // 
            this.hotelBookingDBPaymentDataSet.DataSetName = "HotelBookingDBPaymentDataSet";
            this.hotelBookingDBPaymentDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btnViewReceipt
            // 
            this.btnViewReceipt.Location = new System.Drawing.Point(803, 55);
            this.btnViewReceipt.Name = "btnViewReceipt";
            this.btnViewReceipt.Size = new System.Drawing.Size(182, 29);
            this.btnViewReceipt.TabIndex = 233;
            this.btnViewReceipt.Text = "View Receipt";
            this.btnViewReceipt.UseSelectable = true;
            this.btnViewReceipt.Click += new System.EventHandler(this.btnViewReceipt_Click);
            // 
            // txtCardNumber
            // 
            // 
            // 
            // 
            this.txtCardNumber.CustomButton.Image = null;
            this.txtCardNumber.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtCardNumber.CustomButton.Name = "";
            this.txtCardNumber.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtCardNumber.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtCardNumber.CustomButton.TabIndex = 1;
            this.txtCardNumber.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtCardNumber.CustomButton.UseSelectable = true;
            this.txtCardNumber.CustomButton.Visible = false;
            this.txtCardNumber.Lines = new string[0];
            this.txtCardNumber.Location = new System.Drawing.Point(182, 204);
            this.txtCardNumber.MaxLength = 32767;
            this.txtCardNumber.Name = "txtCardNumber";
            this.txtCardNumber.PasswordChar = '\0';
            this.txtCardNumber.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCardNumber.SelectedText = "";
            this.txtCardNumber.SelectionLength = 0;
            this.txtCardNumber.SelectionStart = 0;
            this.txtCardNumber.ShortcutsEnabled = true;
            this.txtCardNumber.Size = new System.Drawing.Size(235, 23);
            this.txtCardNumber.TabIndex = 211;
            this.txtCardNumber.UseSelectable = true;
            this.txtCardNumber.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtCardNumber.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtCardNumber.TextChanged += new System.EventHandler(this.txtCardNumber_TextChanged);
            // 
            // cboExpDateMonth
            // 
            this.cboExpDateMonth.FormattingEnabled = true;
            this.cboExpDateMonth.ItemHeight = 23;
            this.cboExpDateMonth.Items.AddRange(new object[] {
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12"});
            this.cboExpDateMonth.Location = new System.Drawing.Point(182, 233);
            this.cboExpDateMonth.Name = "cboExpDateMonth";
            this.cboExpDateMonth.Size = new System.Drawing.Size(63, 29);
            this.cboExpDateMonth.TabIndex = 234;
            this.cboExpDateMonth.UseSelectable = true;
            this.cboExpDateMonth.SelectedIndexChanged += new System.EventHandler(this.cboExpDateMonth_SelectedIndexChanged);
            // 
            // cboExpDateYear
            // 
            this.cboExpDateYear.FormattingEnabled = true;
            this.cboExpDateYear.ItemHeight = 23;
            this.cboExpDateYear.Items.AddRange(new object[] {
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28"});
            this.cboExpDateYear.Location = new System.Drawing.Point(277, 233);
            this.cboExpDateYear.Name = "cboExpDateYear";
            this.cboExpDateYear.Size = new System.Drawing.Size(63, 29);
            this.cboExpDateYear.TabIndex = 235;
            this.cboExpDateYear.UseSelectable = true;
            this.cboExpDateYear.SelectedIndexChanged += new System.EventHandler(this.cboExpDateYear_SelectedIndexChanged);
            // 
            // txtExpiryDate
            // 
            // 
            // 
            // 
            this.txtExpiryDate.CustomButton.Image = null;
            this.txtExpiryDate.CustomButton.Location = new System.Drawing.Point(41, 1);
            this.txtExpiryDate.CustomButton.Name = "";
            this.txtExpiryDate.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtExpiryDate.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtExpiryDate.CustomButton.TabIndex = 1;
            this.txtExpiryDate.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtExpiryDate.CustomButton.UseSelectable = true;
            this.txtExpiryDate.CustomButton.Visible = false;
            this.txtExpiryDate.Lines = new string[0];
            this.txtExpiryDate.Location = new System.Drawing.Point(354, 235);
            this.txtExpiryDate.MaxLength = 32767;
            this.txtExpiryDate.Name = "txtExpiryDate";
            this.txtExpiryDate.PasswordChar = '\0';
            this.txtExpiryDate.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtExpiryDate.SelectedText = "";
            this.txtExpiryDate.SelectionLength = 0;
            this.txtExpiryDate.SelectionStart = 0;
            this.txtExpiryDate.ShortcutsEnabled = true;
            this.txtExpiryDate.Size = new System.Drawing.Size(63, 23);
            this.txtExpiryDate.TabIndex = 211;
            this.txtExpiryDate.UseSelectable = true;
            this.txtExpiryDate.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtExpiryDate.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtSecurityCode
            // 
            // 
            // 
            // 
            this.txtSecurityCode.CustomButton.Image = null;
            this.txtSecurityCode.CustomButton.Location = new System.Drawing.Point(41, 1);
            this.txtSecurityCode.CustomButton.Name = "";
            this.txtSecurityCode.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtSecurityCode.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtSecurityCode.CustomButton.TabIndex = 1;
            this.txtSecurityCode.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtSecurityCode.CustomButton.UseSelectable = true;
            this.txtSecurityCode.CustomButton.Visible = false;
            this.txtSecurityCode.Lines = new string[0];
            this.txtSecurityCode.Location = new System.Drawing.Point(182, 270);
            this.txtSecurityCode.MaxLength = 32767;
            this.txtSecurityCode.Name = "txtSecurityCode";
            this.txtSecurityCode.PasswordChar = '\0';
            this.txtSecurityCode.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSecurityCode.SelectedText = "";
            this.txtSecurityCode.SelectionLength = 0;
            this.txtSecurityCode.SelectionStart = 0;
            this.txtSecurityCode.ShortcutsEnabled = true;
            this.txtSecurityCode.Size = new System.Drawing.Size(63, 23);
            this.txtSecurityCode.TabIndex = 211;
            this.txtSecurityCode.UseSelectable = true;
            this.txtSecurityCode.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtSecurityCode.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtCardHolderName
            // 
            // 
            // 
            // 
            this.txtCardHolderName.CustomButton.Image = null;
            this.txtCardHolderName.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtCardHolderName.CustomButton.Name = "";
            this.txtCardHolderName.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtCardHolderName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtCardHolderName.CustomButton.TabIndex = 1;
            this.txtCardHolderName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtCardHolderName.CustomButton.UseSelectable = true;
            this.txtCardHolderName.CustomButton.Visible = false;
            this.txtCardHolderName.Lines = new string[0];
            this.txtCardHolderName.Location = new System.Drawing.Point(182, 302);
            this.txtCardHolderName.MaxLength = 32767;
            this.txtCardHolderName.Name = "txtCardHolderName";
            this.txtCardHolderName.PasswordChar = '\0';
            this.txtCardHolderName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCardHolderName.SelectedText = "";
            this.txtCardHolderName.SelectionLength = 0;
            this.txtCardHolderName.SelectionStart = 0;
            this.txtCardHolderName.ShortcutsEnabled = true;
            this.txtCardHolderName.Size = new System.Drawing.Size(235, 23);
            this.txtCardHolderName.TabIndex = 211;
            this.txtCardHolderName.UseSelectable = true;
            this.txtCardHolderName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtCardHolderName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // paymentTableAdapter
            // 
            this.paymentTableAdapter.ClearBeforeFill = true;
            // 
            // txtEncryptedData
            // 
            // 
            // 
            // 
            this.txtEncryptedData.CustomButton.Image = null;
            this.txtEncryptedData.CustomButton.Location = new System.Drawing.Point(-12, 1);
            this.txtEncryptedData.CustomButton.Name = "";
            this.txtEncryptedData.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtEncryptedData.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtEncryptedData.CustomButton.TabIndex = 1;
            this.txtEncryptedData.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtEncryptedData.CustomButton.UseSelectable = true;
            this.txtEncryptedData.CustomButton.Visible = false;
            this.txtEncryptedData.ForeColor = System.Drawing.Color.Transparent;
            this.txtEncryptedData.Lines = new string[0];
            this.txtEncryptedData.Location = new System.Drawing.Point(423, 204);
            this.txtEncryptedData.MaxLength = 32767;
            this.txtEncryptedData.Name = "txtEncryptedData";
            this.txtEncryptedData.PasswordChar = '\0';
            this.txtEncryptedData.ReadOnly = true;
            this.txtEncryptedData.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtEncryptedData.SelectedText = "";
            this.txtEncryptedData.SelectionLength = 0;
            this.txtEncryptedData.SelectionStart = 0;
            this.txtEncryptedData.ShortcutsEnabled = true;
            this.txtEncryptedData.Size = new System.Drawing.Size(10, 23);
            this.txtEncryptedData.TabIndex = 211;
            this.txtEncryptedData.UseSelectable = true;
            this.txtEncryptedData.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtEncryptedData.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Payment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1008, 650);
            this.Controls.Add(this.txtEncryptedData);
            this.Controls.Add(this.txtCardHolderName);
            this.Controls.Add(this.txtSecurityCode);
            this.Controls.Add(this.txtExpiryDate);
            this.Controls.Add(this.cboExpDateYear);
            this.Controls.Add(this.cboExpDateMonth);
            this.Controls.Add(this.txtCardNumber);
            this.Controls.Add(this.btnViewReceipt);
            this.Controls.Add(this.metroGrid1);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.btnLast);
            this.Controls.Add(this.btnFirst);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.metroLabel8);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.txtSearchRecord);
            this.Controls.Add(this.metroLabel11);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.cboSearchField);
            this.Controls.Add(this.cboFullyPaid);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.txtPaymentAmount);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.rdoFullPayment);
            this.Controls.Add(this.rdoDeposit);
            this.Controls.Add(this.cboType);
            this.Controls.Add(this.txtPaymentID);
            this.Controls.Add(this.txtPaymentDate);
            this.Controls.Add(this.txtBookingID);
            this.Controls.Add(this.metroLabel14);
            this.Controls.Add(this.metroLabel10);
            this.Controls.Add(this.metroLabel13);
            this.Controls.Add(this.metroLabel9);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.shapeContainer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Payment";
            this.Style = MetroFramework.MetroColorStyle.Orange;
            this.Text = "Payment";
            this.Load += new System.EventHandler(this.Payment_Load);
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.paymentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotelBookingDBPaymentDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private MetroFramework.Controls.MetroComboBox cboType;
        private MetroFramework.Controls.MetroTextBox txtPaymentID;
        private MetroFramework.Controls.MetroTextBox txtPaymentDate;
        private MetroFramework.Controls.MetroTextBox txtBookingID;
        private MetroFramework.Controls.MetroLabel metroLabel14;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroRadioButton rdoDeposit;
        private MetroFramework.Controls.MetroRadioButton rdoFullPayment;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTextBox txtPaymentAmount;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroComboBox cboFullyPaid;
        private MetroFramework.Controls.MetroTextBox txtSearchRecord;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroComboBox cboSearchField;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private MetroFramework.Controls.MetroButton btnAdd;
        private MetroFramework.Controls.MetroButton btnNext;
        private MetroFramework.Controls.MetroButton btnPrevious;
        private MetroFramework.Controls.MetroButton btnLast;
        private MetroFramework.Controls.MetroButton btnFirst;
        private MetroFramework.Controls.MetroButton btnSave;
        private MetroFramework.Controls.MetroButton btnDelete;
        private MetroFramework.Controls.MetroGrid metroGrid1;
        private MetroFramework.Controls.MetroButton btnViewReceipt;
        private MetroFramework.Controls.MetroTextBox txtCardNumber;
        private MetroFramework.Controls.MetroComboBox cboExpDateMonth;
        private MetroFramework.Controls.MetroComboBox cboExpDateYear;
        private MetroFramework.Controls.MetroTextBox txtExpiryDate;
        private MetroFramework.Controls.MetroTextBox txtSecurityCode;
        private MetroFramework.Controls.MetroTextBox txtCardHolderName;
        private HotelBookingDBPaymentDataSet hotelBookingDBPaymentDataSet;
        private System.Windows.Forms.BindingSource paymentBindingSource;
        private HotelBookingDBPaymentDataSetTableAdapters.PaymentTableAdapter paymentTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn paymentIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bookingIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn typeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cardNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn securityCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn expiryDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cardHolderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn paymentDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn paymentAmountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fullyPaidDataGridViewTextBoxColumn;
        private MetroFramework.Controls.MetroTextBox txtEncryptedData;
    }
}