﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data.OleDb;
using System.Collections;
using MetroFramework.Forms;

namespace Hotel_Booking_System
{
    public partial class BookRoom : MetroForm
    {
        //Declare global variables
        public static int RoomID = 0;
        public static int? GuestID = null;
        public static string FirstName = null;
        public static string LastName = null;
        public static string Address = null;
        public static string PhoneNumber = null;
        public static string Email = null;
        public static DateTime startDateValue = DateTime.MinValue;
        public static DateTime endDateValue = DateTime.MinValue;
        public static DateTime bookingDate = DateTime.MinValue;
        public static decimal totalCost = 0;
        public static decimal deposit = 0;
        public static decimal finalPrice = 0;
        public static int duration = 0;
        public static string roomResult = null;
        public static string result = null;
        public static string StaffID = Login.StaffID;
        public static string BookingID = null;
        public static int CheckIn = 0;
        public static int CheckOut = 0;
        public static int PeopleNo = 0;

        //Establishes a connection with the SQL database
        SqlConnection cn = new SqlConnection("server=Laptop-PC\\SQLEXPRESS ; database=HotelBookingDB ;Trusted_Connection=True");
        SqlCommand cmdmakebooking = new SqlCommand();
        SqlDataAdapter damakebooking = new SqlDataAdapter();
        DataSet ds = new DataSet();

        public BookRoom()
        {
            InitializeComponent();
            //The default start date is set to tomorrow
            dtpStartDate.Value = DateTime.Today.AddDays(1);
            //The default end date is set to 1 week after the start date
            dtpEndDate.Value = DateTime.Today.AddDays(2);
            //The maximum end date is set to 6 months after the start date
            dtpEndDate.MaxDate = dtpStartDate.Value.AddMonths(6);
        }

        //An ArrayList is set up so that I can store all the variables I need to pass to the Invoice Form
        ArrayList arrayListBookingDetails = new ArrayList();
        
        ArrayList arrayListRoomDetails = new ArrayList();

        private void BookRoom_Load(object sender, EventArgs e)
        {
            
            //TODO: This line of code loads data into the 'hotelBookingDBGuest2DataSet.Guest' table. You can move, or remove it, as needed.
            this.guestTableAdapter.Fill(this.hotelBookingDBGuest2DataSet.Guest);

            this.WindowState = FormWindowState.Maximized;

            //The Make Booking button is disabled until the CheckAvailability button is clicked
            btnMakeBooking.Enabled = false;

            //The start date is set so that it only displays dates up to 6 months ahead
            dtpStartDate.MaxDate = DateTime.Now.AddMonths(6);
        }
        
        private int Getseason(DateTime bookingDate)
        {
            //Sets the price of the bookng according to the month (High. Medium or Low season)
            int month = bookingDate.Month;
            if (month == 12 || month == 1 || month == 2)
            {
                return 1;
            }
            if (month == 3 || month == 4 || month == 5)
            {
                return 2;
            }
            else
            {
                return 3;
            }
        }


        private decimal CalculateTotalPrice(DateTime startDate, DateTime endDate, DateTime bookingDate, int roomId, int index)
        {
            //Calculate amount of nights stayed
            TimeSpan span = endDate.Subtract(startDate);
            duration = span.Days;

            //Gets the High/ Medium/ Low rate from the datagrid
            decimal highRate = Convert.ToDecimal(metroGrid2.Rows[index].Cells[3].Value);
            decimal midRate = Convert.ToDecimal(metroGrid2.Rows[index].Cells[4].Value);
            decimal lowRate = Convert.ToDecimal(metroGrid2.Rows[index].Cells[5].Value);

            int season = Getseason(bookingDate);
            decimal costPerDay = highRate;
            if (season == 1)
            {
                costPerDay = lowRate;
            }
            else if (season == 2)
            {
                costPerDay = midRate;
            }

            //Calculate total price of booking
            totalCost = costPerDay * duration;
            return totalCost;
        }

        private void dtpStartDate_ValueChanged(object sender, EventArgs e)
        {
            //The Make Booking button remains disabled until the CheckAvailability button is clicked
            btnMakeBooking.Enabled = false;
        }

        private void dtpEndDate_ValueChanged(object sender, EventArgs e)
        {
            //The Make Booking button remains disabled until the CheckAvailability button is clicked
            btnMakeBooking.Enabled = false;
        }

        private void btnMakeBooking_Click(object sender, EventArgs e)
        {
            //Establishes a connection with the SQL database
            SqlCommand command = new SqlCommand();
            command.Connection = new SqlConnection(Properties.Resources.HotelBookingDBConnectionString);

            try
            {
                int indexOfSelectedRow = metroGrid1.CurrentCell.RowIndex;

                //The values from the DataGridView are converted to Int32 and strings
                GuestID = Convert.ToInt32(metroGrid1.Rows[indexOfSelectedRow].Cells[0].Value);
                FirstName = metroGrid1.Rows[indexOfSelectedRow].Cells[2].Value.ToString();
                LastName = metroGrid1.Rows[indexOfSelectedRow].Cells[3].Value.ToString();
                Address = metroGrid1.Rows[indexOfSelectedRow].Cells[4].Value.ToString();
                PhoneNumber = metroGrid1.Rows[indexOfSelectedRow].Cells[7].Value.ToString();
                Email = metroGrid1.Rows[indexOfSelectedRow].Cells[8].Value.ToString();
                startDateValue = dtpStartDate.Value;
                endDateValue = dtpEndDate.Value;
                bookingDate = DateTime.Now;

                //Retrieves the RoomID from the DataGridView
                var index = metroGrid2.CurrentCell.RowIndex;
                RoomID = Convert.ToInt32(metroGrid2.Rows[index].Cells[0].Value);

                //The Booking Details from the booking form are passed to the database
                var GetBooking = @"select * from Booking";
                var bookingDataAdapter = new SqlDataAdapter(GetBooking, Properties.Resources.HotelBookingDBConnectionString);

                DataSet booking = new DataSet();
                bookingDataAdapter.FillSchema(booking, SchemaType.Source, "Booking");
                bookingDataAdapter.Fill(booking, "Booking");

                //Sets the values for the Fieldnames
                command.CommandText = "INSERT INTO Booking (GuestID, StaffID, TotalPrice, StartDate, EndDate, BookedDate, Deposit, RoomID, CheckIn, CheckOut) VALUES (@GuestID, @StaffID, @TotalPrice, @StartDate, @EndDate, @BookedDate, @Deposit, @RoomID, @CheckIn, @CheckOut)";

                command.Parameters.Add("@GuestID", SqlDbType.Int, 4, "GuestID");
                command.Parameters.Add("@StaffID", SqlDbType.Int, 4, "StaffID");
                command.Parameters.Add("@StartDate", SqlDbType.DateTime, 5, "StartDate");
                command.Parameters.Add("@EndDate", SqlDbType.DateTime, 5, "EndDate");
                command.Parameters.Add("@BookedDate", SqlDbType.DateTime, 5, "BookedDate");
                command.Parameters.Add("@TotalPrice", SqlDbType.Decimal, 30, "TotalPrice");
                command.Parameters.Add("@Deposit", SqlDbType.Decimal, 30, "Deposit");
                command.Parameters.Add("@RoomID", SqlDbType.Int, 5, "RoomID");
                command.Parameters.Add("@CheckIn", SqlDbType.Bit, 5, "CheckIn");
                command.Parameters.Add("@CheckOut", SqlDbType.Bit, 5, "CheckOut");

                bookingDataAdapter.InsertCommand = command;

                //Calculates total price
                totalCost = CalculateTotalPrice(startDateValue, endDateValue, bookingDate, RoomID, index);

                //Deposit is calculated using the total cost
                deposit = totalCost * 10 / 100;

                //Overall price is calculated
                finalPrice = totalCost - deposit;

                //Retrieves the BookingID from the Booking table
                cn.Open();
                SqlCommand sqlcommand = new SqlCommand("SELECT Top 1 BookingID FROM Booking WHERE GuestID = @GuestID order by BookingID desc", cn);
                sqlcommand.Parameters.AddWithValue("@GuestID", GuestID);
                using (SqlDataReader reader = sqlcommand.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        BookRoom.BookingID = ((string.Format("{0}", reader["BookingID"])));
                    }
                }

                //The booking details are added to an arrayList so they can be sent to the Invoice form
                arrayListBookingDetails.Add("\r\n");
                arrayListBookingDetails.Add("Booking Details");
                arrayListBookingDetails.Add("\r\n");
                arrayListBookingDetails.Add("______________________________________________________________");
                arrayListBookingDetails.Add("\r\n");
                arrayListBookingDetails.Add(" ");
                arrayListBookingDetails.Add("\r\n");

                arrayListBookingDetails.Add("Booking Date: ");
                arrayListBookingDetails.Add(bookingDate);
                arrayListBookingDetails.Add("\r\n");

                arrayListBookingDetails.Add("Booking ID: ");
                arrayListBookingDetails.Add(BookingID);
                arrayListBookingDetails.Add("\r\n");

                arrayListBookingDetails.Add("Guest ID: ");
                arrayListBookingDetails.Add(GuestID);
                arrayListBookingDetails.Add("\r\n");

                arrayListBookingDetails.Add("First Name: ");
                arrayListBookingDetails.Add(FirstName);
                arrayListBookingDetails.Add("\r\n");

                arrayListBookingDetails.Add("Surname: ");
                arrayListBookingDetails.Add(LastName);
                arrayListBookingDetails.Add("\r\n");

                arrayListBookingDetails.Add("Address: ");
                arrayListBookingDetails.Add(Address);
                arrayListBookingDetails.Add("\r\n");

                arrayListBookingDetails.Add("Phone Number: ");
                arrayListBookingDetails.Add(PhoneNumber);
                arrayListBookingDetails.Add("\r\n");

                arrayListBookingDetails.Add("Email: ");
                arrayListBookingDetails.Add(Email);
                arrayListBookingDetails.Add("\r\n");
                arrayListBookingDetails.Add(" ");
                arrayListBookingDetails.Add("\r\n");

                arrayListRoomDetails.Add("Room ID: ");
                arrayListRoomDetails.Add(RoomID);
                arrayListRoomDetails.Add("\r\n");

                arrayListRoomDetails.Add("Number of nights: ");
                arrayListRoomDetails.Add(duration);
                arrayListRoomDetails.Add("\r\n");

                arrayListRoomDetails.Add("Check In Date: ");
                arrayListRoomDetails.Add(startDateValue);
                arrayListRoomDetails.Add("\r\n");

                arrayListRoomDetails.Add("Check Out Date: ");
                arrayListRoomDetails.Add(endDateValue);
                arrayListRoomDetails.Add("\r\n");
                arrayListRoomDetails.Add(" ");
                arrayListRoomDetails.Add("\r\n");

                arrayListRoomDetails.Add("____________________________________________________________");
                arrayListRoomDetails.Add("\r\n");
                arrayListRoomDetails.Add("Cost of nights booked: ");
                arrayListRoomDetails.Add("£" + totalCost);
                arrayListRoomDetails.Add("\r\n");
                arrayListRoomDetails.Add("Deposit: ");
                arrayListRoomDetails.Add("£" + deposit);
                arrayListRoomDetails.Add("\r\n");
                arrayListRoomDetails.Add("____________________________________________________________");
                arrayListRoomDetails.Add("\r\n");
                arrayListRoomDetails.Add(" ");

                //Converts arrayList to stringArray to display it in a textbox on the Invoice form
                result = string.Join("", arrayListBookingDetails.ToArray());
                roomResult = string.Join("", arrayListRoomDetails.ToArray());

                //Confirm booking details
                string message = "Do you want to save these booking details?" + "\n" + "\n" + roomResult;
                DialogResult dialogResult = MessageBox.Show(message, "Confirm Booking Details", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    var newBookingRow = booking.Tables["Booking"].NewRow();
                    newBookingRow["GuestID"] = GuestID;
                    newBookingRow["StaffID"] = StaffID;
                    newBookingRow["StartDate"] = startDateValue;
                    newBookingRow["EndDate"] = endDateValue;
                    newBookingRow["BookedDate"] = bookingDate;
                    newBookingRow["TotalPrice"] = totalCost;
                    newBookingRow["Deposit"] = deposit;
                    newBookingRow["RoomID"] = RoomID;
                    newBookingRow["CheckIn"] = CheckIn;
                    newBookingRow["CheckOut"] = CheckOut;
                    booking.Tables["Booking"].Rows.Add(newBookingRow);
                    bookingDataAdapter.Update(booking, "Booking");

                    btnMakeBooking.Enabled = false;
                    Payment Payment = new Payment();
                    Payment.MdiParent = this.MdiParent;
                    Payment.Show();

                    //Invoice prompt
                    DialogResult dialogResult1 = MessageBox.Show("Would you like an invoice?", "Invoice", MessageBoxButtons.YesNo);
                    if (dialogResult1 == DialogResult.Yes)
                    {
                        Invoice Invoice = new Invoice();
                        Invoice.Show();
                    }
                    else if (dialogResult1 == DialogResult.No)
                    {
                    }

                }
                else if (dialogResult == DialogResult.No)
                {
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Error adding the Booking." + ex.Message);
            }

            finally
            {
            }
        }

        private void btnCheckAvailability_Click(object sender, EventArgs e)
        {
            if (dtpStartDate.Value.Date < DateTime.Now)
            {
                MessageBox.Show("Invalid Start date");
            }
            else if (dtpEndDate.Value.Date < DateTime.Now)
            {
                MessageBox.Show("Invalid End date");
            }
            else
            {
                //Checks the availability of Rooms with the chosen Guest record and complies with Start/End date and Capacity parameters
                SqlCommand command = new SqlCommand();
                command.Connection = new SqlConnection(Properties.Resources.HotelBookingDBConnectionString);
                command.CommandText = "select * from Rooms where RoomID NOT IN (select RoomID from Booking where (StartDate >= @checkInDate and StartDate < @checkOutDate) OR (EndDate > @checkInDate and EndDate <= @checkOutDate)) AND Capacity = @Capacity";

                command.Parameters.Add("@checkInDate", SqlDbType.DateTime).Value = dtpStartDate.Value.Date;
                command.Parameters.Add("@checkOutDate", SqlDbType.DateTime).Value = dtpEndDate.Value.Date;
                command.Parameters.Add("@Capacity", SqlDbType.Int).Value = PeopleNo;

                //The data adapter fills the data set with data from the Rooms table

                SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
                dataAdapter.Fill(this.hotelBookingDBRooms2DataSet.Rooms);

                //The MakeBooking button is available now that the CheckAvailability button has been clicked
                btnMakeBooking.Enabled = true;
            }

        }

        private void txtSearchRecord_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (cboSearchField.SelectedIndex == 0)
                {
                    //Searchs the datagrid for records with a GuestID that complies with the search parameters
                    SqlConnection con = new SqlConnection("Data Source=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");
                    SqlDataAdapter daguest = new SqlDataAdapter("SELECT GuestID, Title, FirstName, LastName, Address, Town, Postcode, PhoneNo, Email FROM Guest where GuestID like '" + txtSearchRecord.Text + "%' ", con);
                    DataTable dt = new DataTable();
                    daguest.Fill(dt);
                    metroGrid1.DataSource = dt;
                }
                else if (cboSearchField.SelectedIndex == 1)
                {
                    //Searchs the datagrid for records with a FirstName that complies with the search parameters
                    SqlConnection con = new SqlConnection("Data Source=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");
                    SqlDataAdapter daguest = new SqlDataAdapter("SELECT GuestID, Title, FirstName, LastName, Address, Town, Postcode, PhoneNo, Email FROM Guest where FirstName like '" + txtSearchRecord.Text + "%' ", con);
                    DataTable dt = new DataTable();
                    daguest.Fill(dt);
                    metroGrid1.DataSource = dt;
                }
                else if (cboSearchField.SelectedIndex == 2)
                {
                    //Searchs the datagrid for records with a LastName that complies with the search parameters
                    SqlConnection con = new SqlConnection("Data Source=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");
                    SqlDataAdapter daguest = new SqlDataAdapter("SELECT GuestID, Title, FirstName, LastName, Address, Town, Postcode, PhoneNo, Email FROM Guest where LastName like '" + txtSearchRecord.Text + "%' ", con);
                    DataTable dt = new DataTable();
                    daguest.Fill(dt);
                    metroGrid1.DataSource = dt;
                }
            }
            catch
            {
            }
        }

        private void cboPeopleNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Sets the PeopleNo according to the item selected from the combo box
            if (cboPeopleNo.SelectedIndex == 0)
            {
                PeopleNo = 2;
            }
            else if (cboPeopleNo.SelectedIndex == 1)
            {
                PeopleNo = 3;
            }
            else if (cboPeopleNo.SelectedIndex == 2)
            {
                PeopleNo = 4;
            }
        }
    }
}

