﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net.Mail;
using MetroFramework.Forms;
using System.Drawing.Printing;

namespace Hotel_Booking_System
{
    public partial class Invoice : MetroForm
    {
        //Declare global variable
        public static string GuestName = BookRoom.FirstName + BookRoom.LastName;

        public Invoice()
        {
            InitializeComponent();

            //Converts arrayList to stringArray and displays it in a textbox
            textBox1.Text = BookRoom.result + BookRoom.roomResult;
        }

        private void btnEmail_Click(object sender, EventArgs e)
        {
            try
            {
                //Sends Email using the Gmail server
                MailMessage mail = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");

                mail.From = new MailAddress("thequinnhotel@gmail.com");
                mail.To.Add(BookRoom.Email);
                mail.Subject = "The Quinn Hotel Invoice " + BookRoom.bookingDate;
                mail.Body = textBox1.Text;

                SmtpServer.Port = 587;
                SmtpServer.Credentials = new System.Net.NetworkCredential("thequinnhotel", "Cactus123");
                SmtpServer.EnableSsl = true;

                SmtpServer.Send(mail);
                MessageBox.Show("Email has been sent to " + BookRoom.Email);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private Font printFont;
        private StringReader streamToPrint;

        private void btnPrint_Click(object sender, EventArgs e)
        {
            //Print textbox contents
            try
            {
                streamToPrint = new StringReader(textBox1.Text);
                try
                {
                    printFont = new Font("Arial", 10);
                    PrintDocument pd = new PrintDocument();
                    pd.PrintPage += new PrintPageEventHandler(this.pd_PrintPage);
                    pd.Print();
                }
                finally
                {
                    streamToPrint.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void pd_PrintPage(object sender, PrintPageEventArgs ev)
        {
            //Set page dimensions
            float linesPerPage = 0;
            float yPos = 0;
            int count = 0;
            float leftMargin = ev.MarginBounds.Left;
            float topMargin = ev.MarginBounds.Top;
            string line = null;

            //Calculate the number of lines per page.
            linesPerPage = ev.MarginBounds.Height /
               printFont.GetHeight(ev.Graphics);

            //Print each line of the file. 
            while (count < linesPerPage &&
               ((line = streamToPrint.ReadLine()) != null))
            {
                yPos = topMargin + (count *
                   printFont.GetHeight(ev.Graphics));
                ev.Graphics.DrawString(line, printFont, Brushes.Black,
                   leftMargin, yPos, new StringFormat());
                count++;
            }

            //If more lines exist, print another page. 
            if (line != null)
                ev.HasMorePages = true;
            else
                ev.HasMorePages = false;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //Declare the file directory
            string fileLocation = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\Invoices\\";

            try
            {
                //Determine whether the folder exists
                if (!Directory.Exists(fileLocation))
                {
                    DirectoryInfo di = Directory.CreateDirectory(fileLocation);
                    //Create new text file in the Invoices folder on the desktop
                    string path = fileLocation + GuestName + ".txt";
                    //Append the file in the Invoices folder on the desktop
                    using (StreamWriter writer = new StreamWriter(path, true))
                    {
                        writer.WriteLine(textBox1.Text);
                    }
                    MessageBox.Show("Saved.");
                    btnSave.Enabled = false;
                }
                else
                {
                    //Create new text file in the Invoices folder on the desktop
                    string path = fileLocation + GuestName + ".txt";
                    //Append the file if it exists already, else creates a new file
                    using (StreamWriter writer = new StreamWriter(path, true))
                    {
                        writer.WriteLine(textBox1.Text);
                    }
                    MessageBox.Show("Saved.");
                    btnSave.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not save invoice." + ex.Message);
            }
            finally
            {
            }
        }
    }
}
