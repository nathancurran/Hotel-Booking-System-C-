﻿namespace Hotel_Booking_System
{
    partial class Bookings
    {
        ///<summary>
        ///Required designer variable.
        ///</summary>
        private System.ComponentModel.IContainer components = null;

        ///<summary>
        ///Clean up any resources being used.
        ///</summary>
        ///<param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        ///<summary>
        ///Required method for Designer support - do not modify
        ///the contents of this method with the code editor.
        ///</summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Bookings));
            this.bookingTableAdapter = new Hotel_Booking_System.HotelBookingDBBookingDataSetTableAdapters.BookingTableAdapter();
            this.btnDelete = new MetroFramework.Controls.MetroButton();
            this.btnSave = new MetroFramework.Controls.MetroButton();
            this.btnFirst = new MetroFramework.Controls.MetroButton();
            this.btnLast = new MetroFramework.Controls.MetroButton();
            this.btnPrevious = new MetroFramework.Controls.MetroButton();
            this.btnNext = new MetroFramework.Controls.MetroButton();
            this.cboSearchField = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.txtBookingID = new MetroFramework.Controls.MetroTextBox();
            this.txtRoomID = new MetroFramework.Controls.MetroTextBox();
            this.txtGuestID = new MetroFramework.Controls.MetroTextBox();
            this.txtStaffID = new MetroFramework.Controls.MetroTextBox();
            this.txtStartDate = new MetroFramework.Controls.MetroTextBox();
            this.txtEndDate = new MetroFramework.Controls.MetroTextBox();
            this.txtBookedDate = new MetroFramework.Controls.MetroTextBox();
            this.txtTotalPrice = new MetroFramework.Controls.MetroTextBox();
            this.txtDeposit = new MetroFramework.Controls.MetroTextBox();
            this.txtSearchRecord = new MetroFramework.Controls.MetroTextBox();
            this.metroGrid1 = new MetroFramework.Controls.MetroGrid();
            this.hotelBookingDBBookingDataSet = new Hotel_Booking_System.HotelBookingDBBookingDataSet();
            this.bookingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bookingIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.roomIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.guestIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.staffIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.endDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bookedDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.depositDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.checkInDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.checkOutDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotelBookingDBBookingDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookingBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // bookingTableAdapter
            // 
            this.bookingTableAdapter.ClearBeforeFill = true;
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnDelete.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btnDelete.Location = new System.Drawing.Point(13, 264);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(91, 32);
            this.btnDelete.TabIndex = 12;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseSelectable = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnSave.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btnSave.Location = new System.Drawing.Point(110, 264);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(91, 32);
            this.btnSave.TabIndex = 13;
            this.btnSave.Text = "Save";
            this.btnSave.UseSelectable = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnFirst
            // 
            this.btnFirst.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnFirst.Location = new System.Drawing.Point(733, 264);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(58, 32);
            this.btnFirst.TabIndex = 14;
            this.btnFirst.Text = "<<";
            this.btnFirst.UseSelectable = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // btnLast
            // 
            this.btnLast.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnLast.Location = new System.Drawing.Point(925, 264);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(58, 32);
            this.btnLast.TabIndex = 17;
            this.btnLast.Text = ">>";
            this.btnLast.UseSelectable = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnPrevious.Location = new System.Drawing.Point(797, 264);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(58, 32);
            this.btnPrevious.TabIndex = 15;
            this.btnPrevious.Text = "<";
            this.btnPrevious.UseSelectable = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnNext
            // 
            this.btnNext.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnNext.Location = new System.Drawing.Point(861, 264);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(58, 32);
            this.btnNext.TabIndex = 16;
            this.btnNext.Text = ">";
            this.btnNext.UseSelectable = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // cboSearchField
            // 
            this.cboSearchField.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cboSearchField.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboSearchField.FormattingEnabled = true;
            this.cboSearchField.ItemHeight = 23;
            this.cboSearchField.Items.AddRange(new object[] {
            "BookingID",
            "RoomID",
            "GuestID",
            "StaffID"});
            this.cboSearchField.Location = new System.Drawing.Point(734, 89);
            this.cboSearchField.Name = "cboSearchField";
            this.cboSearchField.Size = new System.Drawing.Size(234, 29);
            this.cboSearchField.TabIndex = 10;
            this.cboSearchField.UseSelectable = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(13, 70);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(72, 19);
            this.metroLabel2.TabIndex = 151;
            this.metroLabel2.Text = "BookingID:";
            // 
            // metroLabel3
            // 
            this.metroLabel3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(13, 99);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(60, 19);
            this.metroLabel3.TabIndex = 151;
            this.metroLabel3.Text = "RoomID:";
            // 
            // metroLabel4
            // 
            this.metroLabel4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(13, 128);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(56, 19);
            this.metroLabel4.TabIndex = 151;
            this.metroLabel4.Text = "GuestID:";
            // 
            // metroLabel5
            // 
            this.metroLabel5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(13, 157);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(50, 19);
            this.metroLabel5.TabIndex = 151;
            this.metroLabel5.Text = "StaffID:";
            // 
            // metroLabel6
            // 
            this.metroLabel6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(364, 67);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(70, 19);
            this.metroLabel6.TabIndex = 151;
            this.metroLabel6.Text = "Start Date:";
            // 
            // metroLabel1
            // 
            this.metroLabel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel1.Location = new System.Drawing.Point(734, 60);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(103, 25);
            this.metroLabel1.TabIndex = 151;
            this.metroLabel1.Text = "Search Field";
            // 
            // metroLabel11
            // 
            this.metroLabel11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel11.Location = new System.Drawing.Point(733, 124);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(121, 25);
            this.metroLabel11.TabIndex = 151;
            this.metroLabel11.Text = "Search Record";
            // 
            // metroLabel7
            // 
            this.metroLabel7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(364, 98);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(65, 19);
            this.metroLabel7.TabIndex = 151;
            this.metroLabel7.Text = "End Date:";
            // 
            // metroLabel8
            // 
            this.metroLabel8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(364, 125);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(88, 19);
            this.metroLabel8.TabIndex = 151;
            this.metroLabel8.Text = "Booked Date:";
            // 
            // metroLabel9
            // 
            this.metroLabel9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(364, 154);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(74, 19);
            this.metroLabel9.TabIndex = 151;
            this.metroLabel9.Text = "Total Price:";
            // 
            // metroLabel10
            // 
            this.metroLabel10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.Location = new System.Drawing.Point(364, 183);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(56, 19);
            this.metroLabel10.TabIndex = 151;
            this.metroLabel10.Text = "Deposit:";
            // 
            // txtBookingID
            // 
            this.txtBookingID.Anchor = System.Windows.Forms.AnchorStyles.None;
            // 
            // 
            // 
            this.txtBookingID.CustomButton.Image = null;
            this.txtBookingID.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtBookingID.CustomButton.Name = "";
            this.txtBookingID.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtBookingID.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtBookingID.CustomButton.TabIndex = 1;
            this.txtBookingID.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtBookingID.CustomButton.UseSelectable = true;
            this.txtBookingID.CustomButton.Visible = false;
            this.txtBookingID.Lines = new string[0];
            this.txtBookingID.Location = new System.Drawing.Point(102, 66);
            this.txtBookingID.MaxLength = 32767;
            this.txtBookingID.Name = "txtBookingID";
            this.txtBookingID.PasswordChar = '\0';
            this.txtBookingID.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBookingID.SelectedText = "";
            this.txtBookingID.SelectionLength = 0;
            this.txtBookingID.SelectionStart = 0;
            this.txtBookingID.ShortcutsEnabled = true;
            this.txtBookingID.Size = new System.Drawing.Size(235, 23);
            this.txtBookingID.TabIndex = 1;
            this.txtBookingID.UseSelectable = true;
            this.txtBookingID.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtBookingID.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtRoomID
            // 
            this.txtRoomID.Anchor = System.Windows.Forms.AnchorStyles.None;
            // 
            // 
            // 
            this.txtRoomID.CustomButton.Image = null;
            this.txtRoomID.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtRoomID.CustomButton.Name = "";
            this.txtRoomID.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtRoomID.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtRoomID.CustomButton.TabIndex = 1;
            this.txtRoomID.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtRoomID.CustomButton.UseSelectable = true;
            this.txtRoomID.CustomButton.Visible = false;
            this.txtRoomID.Lines = new string[0];
            this.txtRoomID.Location = new System.Drawing.Point(102, 95);
            this.txtRoomID.MaxLength = 32767;
            this.txtRoomID.Name = "txtRoomID";
            this.txtRoomID.PasswordChar = '\0';
            this.txtRoomID.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtRoomID.SelectedText = "";
            this.txtRoomID.SelectionLength = 0;
            this.txtRoomID.SelectionStart = 0;
            this.txtRoomID.ShortcutsEnabled = true;
            this.txtRoomID.Size = new System.Drawing.Size(235, 23);
            this.txtRoomID.TabIndex = 2;
            this.txtRoomID.UseSelectable = true;
            this.txtRoomID.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtRoomID.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtGuestID
            // 
            this.txtGuestID.Anchor = System.Windows.Forms.AnchorStyles.None;
            // 
            // 
            // 
            this.txtGuestID.CustomButton.Image = null;
            this.txtGuestID.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtGuestID.CustomButton.Name = "";
            this.txtGuestID.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtGuestID.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtGuestID.CustomButton.TabIndex = 1;
            this.txtGuestID.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtGuestID.CustomButton.UseSelectable = true;
            this.txtGuestID.CustomButton.Visible = false;
            this.txtGuestID.Lines = new string[0];
            this.txtGuestID.Location = new System.Drawing.Point(102, 124);
            this.txtGuestID.MaxLength = 32767;
            this.txtGuestID.Name = "txtGuestID";
            this.txtGuestID.PasswordChar = '\0';
            this.txtGuestID.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtGuestID.SelectedText = "";
            this.txtGuestID.SelectionLength = 0;
            this.txtGuestID.SelectionStart = 0;
            this.txtGuestID.ShortcutsEnabled = true;
            this.txtGuestID.Size = new System.Drawing.Size(235, 23);
            this.txtGuestID.TabIndex = 3;
            this.txtGuestID.UseSelectable = true;
            this.txtGuestID.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtGuestID.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtStaffID
            // 
            this.txtStaffID.Anchor = System.Windows.Forms.AnchorStyles.None;
            // 
            // 
            // 
            this.txtStaffID.CustomButton.Image = null;
            this.txtStaffID.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtStaffID.CustomButton.Name = "";
            this.txtStaffID.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtStaffID.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtStaffID.CustomButton.TabIndex = 1;
            this.txtStaffID.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtStaffID.CustomButton.UseSelectable = true;
            this.txtStaffID.CustomButton.Visible = false;
            this.txtStaffID.Lines = new string[0];
            this.txtStaffID.Location = new System.Drawing.Point(102, 153);
            this.txtStaffID.MaxLength = 32767;
            this.txtStaffID.Name = "txtStaffID";
            this.txtStaffID.PasswordChar = '\0';
            this.txtStaffID.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtStaffID.SelectedText = "";
            this.txtStaffID.SelectionLength = 0;
            this.txtStaffID.SelectionStart = 0;
            this.txtStaffID.ShortcutsEnabled = true;
            this.txtStaffID.Size = new System.Drawing.Size(235, 23);
            this.txtStaffID.TabIndex = 4;
            this.txtStaffID.UseSelectable = true;
            this.txtStaffID.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtStaffID.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtStartDate
            // 
            this.txtStartDate.Anchor = System.Windows.Forms.AnchorStyles.None;
            // 
            // 
            // 
            this.txtStartDate.CustomButton.Image = null;
            this.txtStartDate.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtStartDate.CustomButton.Name = "";
            this.txtStartDate.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtStartDate.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtStartDate.CustomButton.TabIndex = 1;
            this.txtStartDate.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtStartDate.CustomButton.UseSelectable = true;
            this.txtStartDate.CustomButton.Visible = false;
            this.txtStartDate.Lines = new string[0];
            this.txtStartDate.Location = new System.Drawing.Point(461, 67);
            this.txtStartDate.MaxLength = 32767;
            this.txtStartDate.Name = "txtStartDate";
            this.txtStartDate.PasswordChar = '\0';
            this.txtStartDate.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtStartDate.SelectedText = "";
            this.txtStartDate.SelectionLength = 0;
            this.txtStartDate.SelectionStart = 0;
            this.txtStartDate.ShortcutsEnabled = true;
            this.txtStartDate.Size = new System.Drawing.Size(235, 23);
            this.txtStartDate.TabIndex = 5;
            this.txtStartDate.UseSelectable = true;
            this.txtStartDate.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtStartDate.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtEndDate
            // 
            this.txtEndDate.Anchor = System.Windows.Forms.AnchorStyles.None;
            // 
            // 
            // 
            this.txtEndDate.CustomButton.Image = null;
            this.txtEndDate.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtEndDate.CustomButton.Name = "";
            this.txtEndDate.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtEndDate.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtEndDate.CustomButton.TabIndex = 1;
            this.txtEndDate.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtEndDate.CustomButton.UseSelectable = true;
            this.txtEndDate.CustomButton.Visible = false;
            this.txtEndDate.Lines = new string[0];
            this.txtEndDate.Location = new System.Drawing.Point(461, 96);
            this.txtEndDate.MaxLength = 32767;
            this.txtEndDate.Name = "txtEndDate";
            this.txtEndDate.PasswordChar = '\0';
            this.txtEndDate.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtEndDate.SelectedText = "";
            this.txtEndDate.SelectionLength = 0;
            this.txtEndDate.SelectionStart = 0;
            this.txtEndDate.ShortcutsEnabled = true;
            this.txtEndDate.Size = new System.Drawing.Size(235, 23);
            this.txtEndDate.TabIndex = 6;
            this.txtEndDate.UseSelectable = true;
            this.txtEndDate.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtEndDate.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtBookedDate
            // 
            this.txtBookedDate.Anchor = System.Windows.Forms.AnchorStyles.None;
            // 
            // 
            // 
            this.txtBookedDate.CustomButton.Image = null;
            this.txtBookedDate.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtBookedDate.CustomButton.Name = "";
            this.txtBookedDate.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtBookedDate.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtBookedDate.CustomButton.TabIndex = 1;
            this.txtBookedDate.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtBookedDate.CustomButton.UseSelectable = true;
            this.txtBookedDate.CustomButton.Visible = false;
            this.txtBookedDate.Lines = new string[0];
            this.txtBookedDate.Location = new System.Drawing.Point(461, 125);
            this.txtBookedDate.MaxLength = 32767;
            this.txtBookedDate.Name = "txtBookedDate";
            this.txtBookedDate.PasswordChar = '\0';
            this.txtBookedDate.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBookedDate.SelectedText = "";
            this.txtBookedDate.SelectionLength = 0;
            this.txtBookedDate.SelectionStart = 0;
            this.txtBookedDate.ShortcutsEnabled = true;
            this.txtBookedDate.Size = new System.Drawing.Size(235, 23);
            this.txtBookedDate.TabIndex = 7;
            this.txtBookedDate.UseSelectable = true;
            this.txtBookedDate.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtBookedDate.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtTotalPrice
            // 
            this.txtTotalPrice.Anchor = System.Windows.Forms.AnchorStyles.None;
            // 
            // 
            // 
            this.txtTotalPrice.CustomButton.Image = null;
            this.txtTotalPrice.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtTotalPrice.CustomButton.Name = "";
            this.txtTotalPrice.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtTotalPrice.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtTotalPrice.CustomButton.TabIndex = 1;
            this.txtTotalPrice.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtTotalPrice.CustomButton.UseSelectable = true;
            this.txtTotalPrice.CustomButton.Visible = false;
            this.txtTotalPrice.Lines = new string[0];
            this.txtTotalPrice.Location = new System.Drawing.Point(461, 154);
            this.txtTotalPrice.MaxLength = 32767;
            this.txtTotalPrice.Name = "txtTotalPrice";
            this.txtTotalPrice.PasswordChar = '\0';
            this.txtTotalPrice.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtTotalPrice.SelectedText = "";
            this.txtTotalPrice.SelectionLength = 0;
            this.txtTotalPrice.SelectionStart = 0;
            this.txtTotalPrice.ShortcutsEnabled = true;
            this.txtTotalPrice.Size = new System.Drawing.Size(235, 23);
            this.txtTotalPrice.TabIndex = 8;
            this.txtTotalPrice.UseSelectable = true;
            this.txtTotalPrice.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtTotalPrice.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtDeposit
            // 
            this.txtDeposit.Anchor = System.Windows.Forms.AnchorStyles.None;
            // 
            // 
            // 
            this.txtDeposit.CustomButton.Image = null;
            this.txtDeposit.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtDeposit.CustomButton.Name = "";
            this.txtDeposit.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtDeposit.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtDeposit.CustomButton.TabIndex = 1;
            this.txtDeposit.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtDeposit.CustomButton.UseSelectable = true;
            this.txtDeposit.CustomButton.Visible = false;
            this.txtDeposit.Lines = new string[0];
            this.txtDeposit.Location = new System.Drawing.Point(461, 183);
            this.txtDeposit.MaxLength = 32767;
            this.txtDeposit.Name = "txtDeposit";
            this.txtDeposit.PasswordChar = '\0';
            this.txtDeposit.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtDeposit.SelectedText = "";
            this.txtDeposit.SelectionLength = 0;
            this.txtDeposit.SelectionStart = 0;
            this.txtDeposit.ShortcutsEnabled = true;
            this.txtDeposit.Size = new System.Drawing.Size(235, 23);
            this.txtDeposit.TabIndex = 9;
            this.txtDeposit.UseSelectable = true;
            this.txtDeposit.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtDeposit.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtSearchRecord
            // 
            this.txtSearchRecord.Anchor = System.Windows.Forms.AnchorStyles.None;
            // 
            // 
            // 
            this.txtSearchRecord.CustomButton.Image = null;
            this.txtSearchRecord.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtSearchRecord.CustomButton.Name = "";
            this.txtSearchRecord.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtSearchRecord.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtSearchRecord.CustomButton.TabIndex = 1;
            this.txtSearchRecord.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtSearchRecord.CustomButton.UseSelectable = true;
            this.txtSearchRecord.CustomButton.Visible = false;
            this.txtSearchRecord.Lines = new string[0];
            this.txtSearchRecord.Location = new System.Drawing.Point(733, 152);
            this.txtSearchRecord.MaxLength = 32767;
            this.txtSearchRecord.Name = "txtSearchRecord";
            this.txtSearchRecord.PasswordChar = '\0';
            this.txtSearchRecord.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSearchRecord.SelectedText = "";
            this.txtSearchRecord.SelectionLength = 0;
            this.txtSearchRecord.SelectionStart = 0;
            this.txtSearchRecord.ShortcutsEnabled = true;
            this.txtSearchRecord.Size = new System.Drawing.Size(235, 23);
            this.txtSearchRecord.TabIndex = 11;
            this.txtSearchRecord.UseSelectable = true;
            this.txtSearchRecord.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtSearchRecord.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtSearchRecord.TextChanged += new System.EventHandler(this.txtSearchRecord_TextChanged);
            // 
            // metroGrid1
            // 
            this.metroGrid1.AllowUserToResizeRows = false;
            this.metroGrid1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroGrid1.AutoGenerateColumns = false;
            this.metroGrid1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.metroGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.metroGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.bookingIDDataGridViewTextBoxColumn,
            this.roomIDDataGridViewTextBoxColumn,
            this.guestIDDataGridViewTextBoxColumn,
            this.staffIDDataGridViewTextBoxColumn,
            this.startDateDataGridViewTextBoxColumn,
            this.endDateDataGridViewTextBoxColumn,
            this.bookedDateDataGridViewTextBoxColumn,
            this.totalPriceDataGridViewTextBoxColumn,
            this.depositDataGridViewTextBoxColumn,
            this.checkInDataGridViewCheckBoxColumn,
            this.checkOutDataGridViewCheckBoxColumn});
            this.metroGrid1.DataSource = this.bookingBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid1.DefaultCellStyle = dataGridViewCellStyle2;
            this.metroGrid1.EnableHeadersVisualStyles = false;
            this.metroGrid1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid1.Location = new System.Drawing.Point(13, 302);
            this.metroGrid1.Name = "metroGrid1";
            this.metroGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.metroGrid1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid1.Size = new System.Drawing.Size(970, 250);
            this.metroGrid1.TabIndex = 18;
            // 
            // hotelBookingDBBookingDataSet
            // 
            this.hotelBookingDBBookingDataSet.DataSetName = "HotelBookingDBBookingDataSet";
            this.hotelBookingDBBookingDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bookingBindingSource
            // 
            this.bookingBindingSource.DataMember = "Booking";
            this.bookingBindingSource.DataSource = this.hotelBookingDBBookingDataSet;
            // 
            // bookingIDDataGridViewTextBoxColumn
            // 
            this.bookingIDDataGridViewTextBoxColumn.DataPropertyName = "BookingID";
            this.bookingIDDataGridViewTextBoxColumn.HeaderText = "BookingID";
            this.bookingIDDataGridViewTextBoxColumn.Name = "bookingIDDataGridViewTextBoxColumn";
            this.bookingIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // roomIDDataGridViewTextBoxColumn
            // 
            this.roomIDDataGridViewTextBoxColumn.DataPropertyName = "RoomID";
            this.roomIDDataGridViewTextBoxColumn.HeaderText = "RoomID";
            this.roomIDDataGridViewTextBoxColumn.Name = "roomIDDataGridViewTextBoxColumn";
            // 
            // guestIDDataGridViewTextBoxColumn
            // 
            this.guestIDDataGridViewTextBoxColumn.DataPropertyName = "GuestID";
            this.guestIDDataGridViewTextBoxColumn.HeaderText = "GuestID";
            this.guestIDDataGridViewTextBoxColumn.Name = "guestIDDataGridViewTextBoxColumn";
            // 
            // staffIDDataGridViewTextBoxColumn
            // 
            this.staffIDDataGridViewTextBoxColumn.DataPropertyName = "StaffID";
            this.staffIDDataGridViewTextBoxColumn.HeaderText = "StaffID";
            this.staffIDDataGridViewTextBoxColumn.Name = "staffIDDataGridViewTextBoxColumn";
            // 
            // startDateDataGridViewTextBoxColumn
            // 
            this.startDateDataGridViewTextBoxColumn.DataPropertyName = "StartDate";
            this.startDateDataGridViewTextBoxColumn.HeaderText = "StartDate";
            this.startDateDataGridViewTextBoxColumn.Name = "startDateDataGridViewTextBoxColumn";
            // 
            // endDateDataGridViewTextBoxColumn
            // 
            this.endDateDataGridViewTextBoxColumn.DataPropertyName = "EndDate";
            this.endDateDataGridViewTextBoxColumn.HeaderText = "EndDate";
            this.endDateDataGridViewTextBoxColumn.Name = "endDateDataGridViewTextBoxColumn";
            // 
            // bookedDateDataGridViewTextBoxColumn
            // 
            this.bookedDateDataGridViewTextBoxColumn.DataPropertyName = "BookedDate";
            this.bookedDateDataGridViewTextBoxColumn.HeaderText = "BookedDate";
            this.bookedDateDataGridViewTextBoxColumn.Name = "bookedDateDataGridViewTextBoxColumn";
            // 
            // totalPriceDataGridViewTextBoxColumn
            // 
            this.totalPriceDataGridViewTextBoxColumn.DataPropertyName = "TotalPrice";
            this.totalPriceDataGridViewTextBoxColumn.HeaderText = "TotalPrice";
            this.totalPriceDataGridViewTextBoxColumn.Name = "totalPriceDataGridViewTextBoxColumn";
            // 
            // depositDataGridViewTextBoxColumn
            // 
            this.depositDataGridViewTextBoxColumn.DataPropertyName = "Deposit";
            this.depositDataGridViewTextBoxColumn.HeaderText = "Deposit";
            this.depositDataGridViewTextBoxColumn.Name = "depositDataGridViewTextBoxColumn";
            // 
            // checkInDataGridViewCheckBoxColumn
            // 
            this.checkInDataGridViewCheckBoxColumn.DataPropertyName = "CheckIn";
            this.checkInDataGridViewCheckBoxColumn.HeaderText = "CheckIn";
            this.checkInDataGridViewCheckBoxColumn.Name = "checkInDataGridViewCheckBoxColumn";
            // 
            // checkOutDataGridViewCheckBoxColumn
            // 
            this.checkOutDataGridViewCheckBoxColumn.DataPropertyName = "CheckOut";
            this.checkOutDataGridViewCheckBoxColumn.HeaderText = "CheckOut";
            this.checkOutDataGridViewCheckBoxColumn.Name = "checkOutDataGridViewCheckBoxColumn";
            // 
            // Bookings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(995, 575);
            this.Controls.Add(this.metroGrid1);
            this.Controls.Add(this.txtSearchRecord);
            this.Controls.Add(this.txtDeposit);
            this.Controls.Add(this.txtTotalPrice);
            this.Controls.Add(this.txtBookedDate);
            this.Controls.Add(this.txtEndDate);
            this.Controls.Add(this.txtStartDate);
            this.Controls.Add(this.txtStaffID);
            this.Controls.Add(this.txtGuestID);
            this.Controls.Add(this.txtRoomID);
            this.Controls.Add(this.txtBookingID);
            this.Controls.Add(this.metroLabel10);
            this.Controls.Add(this.metroLabel9);
            this.Controls.Add(this.metroLabel8);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.metroLabel11);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.cboSearchField);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.btnLast);
            this.Controls.Add(this.btnFirst);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDelete);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Bookings";
            this.Style = MetroFramework.MetroColorStyle.Orange;
            this.Text = "Bookings";
            this.Load += new System.EventHandler(this.Bookings_Load);
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotelBookingDBBookingDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookingBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private HotelBookingDBBookingDataSetTableAdapters.BookingTableAdapter bookingTableAdapter;
        private MetroFramework.Controls.MetroButton btnDelete;
        private MetroFramework.Controls.MetroButton btnSave;
        private MetroFramework.Controls.MetroButton btnFirst;
        private MetroFramework.Controls.MetroButton btnLast;
        private MetroFramework.Controls.MetroButton btnPrevious;
        private MetroFramework.Controls.MetroButton btnNext;
        private MetroFramework.Controls.MetroComboBox cboSearchField;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroTextBox txtBookingID;
        private MetroFramework.Controls.MetroTextBox txtRoomID;
        private MetroFramework.Controls.MetroTextBox txtGuestID;
        private MetroFramework.Controls.MetroTextBox txtStaffID;
        private MetroFramework.Controls.MetroTextBox txtStartDate;
        private MetroFramework.Controls.MetroTextBox txtEndDate;
        private MetroFramework.Controls.MetroTextBox txtBookedDate;
        private MetroFramework.Controls.MetroTextBox txtTotalPrice;
        private MetroFramework.Controls.MetroTextBox txtDeposit;
        private MetroFramework.Controls.MetroTextBox txtSearchRecord;
        private MetroFramework.Controls.MetroGrid metroGrid1;
        private HotelBookingDBBookingDataSet hotelBookingDBBookingDataSet;
        private System.Windows.Forms.BindingSource bookingBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn bookingIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn roomIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn guestIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn staffIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn endDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bookedDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn depositDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn checkInDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn checkOutDataGridViewCheckBoxColumn;
    }
}