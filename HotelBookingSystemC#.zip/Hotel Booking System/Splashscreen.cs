﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using MetroFramework.Forms;
using System.Threading.Tasks;

namespace Hotel_Booking_System
{
    public partial class Splashscreen : MetroForm
    {
        public Splashscreen()
        {
            InitializeComponent();
        }

        private void Splashscreen_Load(object sender, EventArgs e)
        {
            lblPcName.Text = System.Environment.MachineName;
            //Sets max value for progressbar
            metroProgressBar1.Maximum = 10;
            //Sets timer
            timer1.Interval = 500;
            timer1.Tick += new EventHandler(timer1_Tick);
             
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //Starts progressbar on a loop until the max value is acheived
            if (metroProgressBar1.Value != 10)
            {
                metroProgressBar1.Value++;
            }
            else
            {
                timer1.Stop();
            }            
        }
    }
} 
