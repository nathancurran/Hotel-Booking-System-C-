﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotel_Booking_System
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void viewBookingsToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Bookings nextScreen = new Bookings();
            nextScreen.Show();
            this.Hide();
        }

        private void editBookingsToolStripMenuItem_Click(object sender, EventArgs e)
        {

            BookRoom nextScreen = new BookRoom();
            nextScreen.Show();
            this.Hide();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Login nextScreen = new Login();
            nextScreen.Show();
            this.Hide();
        }

        private void staffToolStripMenuItem_Click(object sender, EventArgs e)
        {
           Staff nextScreen = new Staff();
            nextScreen.Show();
            this.Hide();
        }

        private void paymentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Payment nextScreen = new Payment();
            nextScreen.Show();
            this.Hide();
        }

        private void guestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Guest nextScreen = new Guest();
            nextScreen.Show();
            this.Hide();
        }

        private void roomsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Rooms nextScreen = new Rooms();
            nextScreen.Show();
            this.Hide();
        }

    }
}
