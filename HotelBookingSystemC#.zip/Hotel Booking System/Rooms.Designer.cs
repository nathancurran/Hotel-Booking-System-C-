﻿namespace Hotel_Booking_System
{
    partial class Rooms
    {
        ///<summary>
        ///Required designer variable.
        ///</summary>
        private System.ComponentModel.IContainer components = null;

        ///<summary>
        ///Clean up any resources being used.
        ///</summary>
        ///<param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        ///<summary>
        ///Required method for Designer support - do not modify
        ///the contents of this method with the code editor.
        ///</summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Rooms));
            this.btnAdd = new MetroFramework.Controls.MetroButton();
            this.txtSearchRecord = new MetroFramework.Controls.MetroTextBox();
            this.txtLow = new MetroFramework.Controls.MetroTextBox();
            this.txtMedium = new MetroFramework.Controls.MetroTextBox();
            this.txtHigh = new MetroFramework.Controls.MetroTextBox();
            this.txtCapacity = new MetroFramework.Controls.MetroTextBox();
            this.txtRoomID = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.cboSearchField = new MetroFramework.Controls.MetroComboBox();
            this.btnNext = new MetroFramework.Controls.MetroButton();
            this.btnPrevious = new MetroFramework.Controls.MetroButton();
            this.btnLast = new MetroFramework.Controls.MetroButton();
            this.btnFirst = new MetroFramework.Controls.MetroButton();
            this.btnSave = new MetroFramework.Controls.MetroButton();
            this.btnDelete = new MetroFramework.Controls.MetroButton();
            this.metroGrid1 = new MetroFramework.Controls.MetroGrid();
            this.roomsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.hotelBookingDBRoomsDataSet = new Hotel_Booking_System.HotelBookingDBRoomsDataSet();
            this.roomsTableAdapter = new Hotel_Booking_System.HotelBookingDBRoomsDataSetTableAdapters.RoomsTableAdapter();
            this.cboRoomType = new MetroFramework.Controls.MetroComboBox();
            this.cboRating = new MetroFramework.Controls.MetroComboBox();
            this.roomIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.typeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.capacityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ratingDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.highDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mediumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lowDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roomsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotelBookingDBRoomsDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAdd
            // 
            this.btnAdd.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btnAdd.Location = new System.Drawing.Point(23, 254);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(91, 32);
            this.btnAdd.TabIndex = 10;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseSelectable = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // txtSearchRecord
            // 
            // 
            // 
            // 
            this.txtSearchRecord.CustomButton.Image = null;
            this.txtSearchRecord.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtSearchRecord.CustomButton.Name = "";
            this.txtSearchRecord.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtSearchRecord.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtSearchRecord.CustomButton.TabIndex = 1;
            this.txtSearchRecord.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtSearchRecord.CustomButton.UseSelectable = true;
            this.txtSearchRecord.CustomButton.Visible = false;
            this.txtSearchRecord.Lines = new string[0];
            this.txtSearchRecord.Location = new System.Drawing.Point(743, 142);
            this.txtSearchRecord.MaxLength = 32767;
            this.txtSearchRecord.Name = "txtSearchRecord";
            this.txtSearchRecord.PasswordChar = '\0';
            this.txtSearchRecord.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSearchRecord.SelectedText = "";
            this.txtSearchRecord.SelectionLength = 0;
            this.txtSearchRecord.SelectionStart = 0;
            this.txtSearchRecord.ShortcutsEnabled = true;
            this.txtSearchRecord.Size = new System.Drawing.Size(235, 23);
            this.txtSearchRecord.TabIndex = 9;
            this.txtSearchRecord.UseSelectable = true;
            this.txtSearchRecord.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtSearchRecord.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtSearchRecord.TextChanged += new System.EventHandler(this.txtSearchRecord_TextChanged);
            // 
            // txtLow
            // 
            // 
            // 
            // 
            this.txtLow.CustomButton.Image = null;
            this.txtLow.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtLow.CustomButton.Name = "";
            this.txtLow.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtLow.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtLow.CustomButton.TabIndex = 1;
            this.txtLow.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtLow.CustomButton.UseSelectable = true;
            this.txtLow.CustomButton.Visible = false;
            this.txtLow.Lines = new string[0];
            this.txtLow.Location = new System.Drawing.Point(471, 115);
            this.txtLow.MaxLength = 32767;
            this.txtLow.Name = "txtLow";
            this.txtLow.PasswordChar = '\0';
            this.txtLow.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtLow.SelectedText = "";
            this.txtLow.SelectionLength = 0;
            this.txtLow.SelectionStart = 0;
            this.txtLow.ShortcutsEnabled = true;
            this.txtLow.Size = new System.Drawing.Size(235, 23);
            this.txtLow.TabIndex = 7;
            this.txtLow.UseSelectable = true;
            this.txtLow.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtLow.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtMedium
            // 
            // 
            // 
            // 
            this.txtMedium.CustomButton.Image = null;
            this.txtMedium.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtMedium.CustomButton.Name = "";
            this.txtMedium.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtMedium.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtMedium.CustomButton.TabIndex = 1;
            this.txtMedium.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtMedium.CustomButton.UseSelectable = true;
            this.txtMedium.CustomButton.Visible = false;
            this.txtMedium.Lines = new string[0];
            this.txtMedium.Location = new System.Drawing.Point(471, 86);
            this.txtMedium.MaxLength = 32767;
            this.txtMedium.Name = "txtMedium";
            this.txtMedium.PasswordChar = '\0';
            this.txtMedium.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtMedium.SelectedText = "";
            this.txtMedium.SelectionLength = 0;
            this.txtMedium.SelectionStart = 0;
            this.txtMedium.ShortcutsEnabled = true;
            this.txtMedium.Size = new System.Drawing.Size(235, 23);
            this.txtMedium.TabIndex = 6;
            this.txtMedium.UseSelectable = true;
            this.txtMedium.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtMedium.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtHigh
            // 
            // 
            // 
            // 
            this.txtHigh.CustomButton.Image = null;
            this.txtHigh.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtHigh.CustomButton.Name = "";
            this.txtHigh.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtHigh.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtHigh.CustomButton.TabIndex = 1;
            this.txtHigh.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtHigh.CustomButton.UseSelectable = true;
            this.txtHigh.CustomButton.Visible = false;
            this.txtHigh.Lines = new string[0];
            this.txtHigh.Location = new System.Drawing.Point(471, 57);
            this.txtHigh.MaxLength = 32767;
            this.txtHigh.Name = "txtHigh";
            this.txtHigh.PasswordChar = '\0';
            this.txtHigh.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtHigh.SelectedText = "";
            this.txtHigh.SelectionLength = 0;
            this.txtHigh.SelectionStart = 0;
            this.txtHigh.ShortcutsEnabled = true;
            this.txtHigh.Size = new System.Drawing.Size(235, 23);
            this.txtHigh.TabIndex = 5;
            this.txtHigh.UseSelectable = true;
            this.txtHigh.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtHigh.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtCapacity
            // 
            // 
            // 
            // 
            this.txtCapacity.CustomButton.Image = null;
            this.txtCapacity.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtCapacity.CustomButton.Name = "";
            this.txtCapacity.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtCapacity.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtCapacity.CustomButton.TabIndex = 1;
            this.txtCapacity.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtCapacity.CustomButton.UseSelectable = true;
            this.txtCapacity.CustomButton.Visible = false;
            this.txtCapacity.Lines = new string[0];
            this.txtCapacity.Location = new System.Drawing.Point(112, 120);
            this.txtCapacity.MaxLength = 32767;
            this.txtCapacity.Name = "txtCapacity";
            this.txtCapacity.PasswordChar = '\0';
            this.txtCapacity.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCapacity.SelectedText = "";
            this.txtCapacity.SelectionLength = 0;
            this.txtCapacity.SelectionStart = 0;
            this.txtCapacity.ShortcutsEnabled = true;
            this.txtCapacity.Size = new System.Drawing.Size(235, 23);
            this.txtCapacity.TabIndex = 3;
            this.txtCapacity.UseSelectable = true;
            this.txtCapacity.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtCapacity.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtRoomID
            // 
            // 
            // 
            // 
            this.txtRoomID.CustomButton.Image = null;
            this.txtRoomID.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtRoomID.CustomButton.Name = "";
            this.txtRoomID.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtRoomID.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtRoomID.CustomButton.TabIndex = 1;
            this.txtRoomID.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtRoomID.CustomButton.UseSelectable = true;
            this.txtRoomID.CustomButton.Visible = false;
            this.txtRoomID.Lines = new string[0];
            this.txtRoomID.Location = new System.Drawing.Point(112, 56);
            this.txtRoomID.MaxLength = 32767;
            this.txtRoomID.Name = "txtRoomID";
            this.txtRoomID.PasswordChar = '\0';
            this.txtRoomID.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtRoomID.SelectedText = "";
            this.txtRoomID.SelectionLength = 0;
            this.txtRoomID.SelectionStart = 0;
            this.txtRoomID.ShortcutsEnabled = true;
            this.txtRoomID.Size = new System.Drawing.Size(235, 23);
            this.txtRoomID.TabIndex = 1;
            this.txtRoomID.UseSelectable = true;
            this.txtRoomID.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtRoomID.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(374, 115);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(35, 19);
            this.metroLabel8.TabIndex = 198;
            this.metroLabel8.Text = "Low:";
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(374, 88);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(61, 19);
            this.metroLabel7.TabIndex = 208;
            this.metroLabel7.Text = "Medium:";
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel11.Location = new System.Drawing.Point(743, 114);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(121, 25);
            this.metroLabel11.TabIndex = 199;
            this.metroLabel11.Text = "Search Record";
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel1.Location = new System.Drawing.Point(744, 50);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(103, 25);
            this.metroLabel1.TabIndex = 200;
            this.metroLabel1.Text = "Search Field";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(374, 57);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(39, 19);
            this.metroLabel6.TabIndex = 201;
            this.metroLabel6.Text = "High:";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(23, 159);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(49, 19);
            this.metroLabel5.TabIndex = 202;
            this.metroLabel5.Text = "Rating:";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(23, 124);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(62, 19);
            this.metroLabel4.TabIndex = 203;
            this.metroLabel4.Text = "Capacity:";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(23, 89);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(80, 19);
            this.metroLabel3.TabIndex = 204;
            this.metroLabel3.Text = "Room Type:";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(23, 60);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(60, 19);
            this.metroLabel2.TabIndex = 205;
            this.metroLabel2.Text = "RoomID:";
            // 
            // cboSearchField
            // 
            this.cboSearchField.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboSearchField.FormattingEnabled = true;
            this.cboSearchField.ItemHeight = 23;
            this.cboSearchField.Items.AddRange(new object[] {
            "RoomID",
            "Type",
            "Capacity",
            "Rating"});
            this.cboSearchField.Location = new System.Drawing.Point(744, 79);
            this.cboSearchField.Name = "cboSearchField";
            this.cboSearchField.Size = new System.Drawing.Size(234, 29);
            this.cboSearchField.TabIndex = 8;
            this.cboSearchField.UseSelectable = true;
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(871, 254);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(58, 32);
            this.btnNext.TabIndex = 15;
            this.btnNext.Text = ">";
            this.btnNext.UseSelectable = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Location = new System.Drawing.Point(807, 254);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(58, 32);
            this.btnPrevious.TabIndex = 14;
            this.btnPrevious.Text = "<";
            this.btnPrevious.UseSelectable = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnLast
            // 
            this.btnLast.Location = new System.Drawing.Point(935, 254);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(58, 32);
            this.btnLast.TabIndex = 16;
            this.btnLast.Text = ">>";
            this.btnLast.UseSelectable = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // btnFirst
            // 
            this.btnFirst.Location = new System.Drawing.Point(743, 254);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(58, 32);
            this.btnFirst.TabIndex = 13;
            this.btnFirst.Text = "<<";
            this.btnFirst.UseSelectable = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // btnSave
            // 
            this.btnSave.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btnSave.Location = new System.Drawing.Point(217, 254);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(91, 32);
            this.btnSave.TabIndex = 12;
            this.btnSave.Text = "Save";
            this.btnSave.UseSelectable = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btnDelete.Location = new System.Drawing.Point(120, 254);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(91, 32);
            this.btnDelete.TabIndex = 11;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseSelectable = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // metroGrid1
            // 
            this.metroGrid1.AllowUserToResizeRows = false;
            this.metroGrid1.AutoGenerateColumns = false;
            this.metroGrid1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.metroGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.metroGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.roomIDDataGridViewTextBoxColumn,
            this.typeDataGridViewTextBoxColumn,
            this.capacityDataGridViewTextBoxColumn,
            this.ratingDataGridViewTextBoxColumn,
            this.highDataGridViewTextBoxColumn,
            this.mediumDataGridViewTextBoxColumn,
            this.lowDataGridViewTextBoxColumn});
            this.metroGrid1.DataSource = this.roomsBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid1.DefaultCellStyle = dataGridViewCellStyle2;
            this.metroGrid1.EnableHeadersVisualStyles = false;
            this.metroGrid1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid1.Location = new System.Drawing.Point(23, 292);
            this.metroGrid1.Name = "metroGrid1";
            this.metroGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.metroGrid1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid1.Size = new System.Drawing.Size(970, 277);
            this.metroGrid1.TabIndex = 17;
            // 
            // roomsBindingSource
            // 
            this.roomsBindingSource.DataMember = "Rooms";
            this.roomsBindingSource.DataSource = this.hotelBookingDBRoomsDataSet;
            // 
            // hotelBookingDBRoomsDataSet
            // 
            this.hotelBookingDBRoomsDataSet.DataSetName = "HotelBookingDBRoomsDataSet";
            this.hotelBookingDBRoomsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // roomsTableAdapter
            // 
            this.roomsTableAdapter.ClearBeforeFill = true;
            // 
            // cboRoomType
            // 
            this.cboRoomType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboRoomType.FormattingEnabled = true;
            this.cboRoomType.ItemHeight = 23;
            this.cboRoomType.Items.AddRange(new object[] {
            "Twin",
            "Double",
            "Triple",
            "Deluxe"});
            this.cboRoomType.Location = new System.Drawing.Point(112, 85);
            this.cboRoomType.Name = "cboRoomType";
            this.cboRoomType.Size = new System.Drawing.Size(235, 29);
            this.cboRoomType.TabIndex = 2;
            this.cboRoomType.UseSelectable = true;
            // 
            // cboRating
            // 
            this.cboRating.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboRating.FormattingEnabled = true;
            this.cboRating.ItemHeight = 23;
            this.cboRating.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cboRating.Location = new System.Drawing.Point(112, 153);
            this.cboRating.Name = "cboRating";
            this.cboRating.Size = new System.Drawing.Size(85, 29);
            this.cboRating.TabIndex = 4;
            this.cboRating.UseSelectable = true;
            // 
            // roomIDDataGridViewTextBoxColumn
            // 
            this.roomIDDataGridViewTextBoxColumn.DataPropertyName = "RoomID";
            this.roomIDDataGridViewTextBoxColumn.HeaderText = "RoomID";
            this.roomIDDataGridViewTextBoxColumn.Name = "roomIDDataGridViewTextBoxColumn";
            // 
            // typeDataGridViewTextBoxColumn
            // 
            this.typeDataGridViewTextBoxColumn.DataPropertyName = "Type";
            this.typeDataGridViewTextBoxColumn.HeaderText = "Type";
            this.typeDataGridViewTextBoxColumn.Name = "typeDataGridViewTextBoxColumn";
            // 
            // capacityDataGridViewTextBoxColumn
            // 
            this.capacityDataGridViewTextBoxColumn.DataPropertyName = "Capacity";
            this.capacityDataGridViewTextBoxColumn.HeaderText = "Capacity";
            this.capacityDataGridViewTextBoxColumn.Name = "capacityDataGridViewTextBoxColumn";
            // 
            // ratingDataGridViewTextBoxColumn
            // 
            this.ratingDataGridViewTextBoxColumn.DataPropertyName = "Rating";
            this.ratingDataGridViewTextBoxColumn.HeaderText = "Rating";
            this.ratingDataGridViewTextBoxColumn.Name = "ratingDataGridViewTextBoxColumn";
            // 
            // highDataGridViewTextBoxColumn
            // 
            this.highDataGridViewTextBoxColumn.DataPropertyName = "High";
            this.highDataGridViewTextBoxColumn.HeaderText = "High";
            this.highDataGridViewTextBoxColumn.Name = "highDataGridViewTextBoxColumn";
            // 
            // mediumDataGridViewTextBoxColumn
            // 
            this.mediumDataGridViewTextBoxColumn.DataPropertyName = "Medium";
            this.mediumDataGridViewTextBoxColumn.HeaderText = "Medium";
            this.mediumDataGridViewTextBoxColumn.Name = "mediumDataGridViewTextBoxColumn";
            // 
            // lowDataGridViewTextBoxColumn
            // 
            this.lowDataGridViewTextBoxColumn.DataPropertyName = "Low";
            this.lowDataGridViewTextBoxColumn.HeaderText = "Low";
            this.lowDataGridViewTextBoxColumn.Name = "lowDataGridViewTextBoxColumn";
            // 
            // Rooms
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1005, 592);
            this.Controls.Add(this.cboRating);
            this.Controls.Add(this.cboRoomType);
            this.Controls.Add(this.metroGrid1);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtSearchRecord);
            this.Controls.Add(this.txtLow);
            this.Controls.Add(this.txtMedium);
            this.Controls.Add(this.txtHigh);
            this.Controls.Add(this.txtCapacity);
            this.Controls.Add(this.txtRoomID);
            this.Controls.Add(this.metroLabel8);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.metroLabel11);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.cboSearchField);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.btnLast);
            this.Controls.Add(this.btnFirst);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDelete);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Rooms";
            this.Style = MetroFramework.MetroColorStyle.Orange;
            this.Text = "Rooms";
            this.Load += new System.EventHandler(this.Rooms_Load);
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roomsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotelBookingDBRoomsDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroButton btnAdd;
        private MetroFramework.Controls.MetroTextBox txtSearchRecord;
        private MetroFramework.Controls.MetroTextBox txtLow;
        private MetroFramework.Controls.MetroTextBox txtMedium;
        private MetroFramework.Controls.MetroTextBox txtHigh;
        private MetroFramework.Controls.MetroTextBox txtCapacity;
        private MetroFramework.Controls.MetroTextBox txtRoomID;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroComboBox cboSearchField;
        private MetroFramework.Controls.MetroButton btnNext;
        private MetroFramework.Controls.MetroButton btnPrevious;
        private MetroFramework.Controls.MetroButton btnLast;
        private MetroFramework.Controls.MetroButton btnFirst;
        private MetroFramework.Controls.MetroButton btnSave;
        private MetroFramework.Controls.MetroButton btnDelete;
        private MetroFramework.Controls.MetroGrid metroGrid1;
        private HotelBookingDBRoomsDataSet hotelBookingDBRoomsDataSet;
        private System.Windows.Forms.BindingSource roomsBindingSource;
        private HotelBookingDBRoomsDataSetTableAdapters.RoomsTableAdapter roomsTableAdapter;
        private MetroFramework.Controls.MetroComboBox cboRoomType;
        private MetroFramework.Controls.MetroComboBox cboRating;
        private System.Windows.Forms.DataGridViewTextBoxColumn roomIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn typeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn capacityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ratingDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn highDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mediumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lowDataGridViewTextBoxColumn;
    }
}