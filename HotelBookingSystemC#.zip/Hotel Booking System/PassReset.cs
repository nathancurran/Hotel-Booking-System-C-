﻿using MetroFramework.Forms;
using Salt_Password_Sample;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotel_Booking_System
{
    public partial class PassReset : MetroForm
    {
        //Declare global variables
        public static string Email = null;
        public static string password = "Password1";

        //Establishes a connection with the SQL database
        SqlConnection cn = new SqlConnection("server=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");

        public PassReset()
        {
            InitializeComponent();
        }

        private void PassReset_Load(object sender, EventArgs e)
        {
            cn.Open();

            //Fills the Username combobox with the usernames from the Staff table
            string sql = "select * from Staff";
            SqlCommand cmd = new SqlCommand(sql, cn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            DataTable table = ds.Tables[0];
            for (int i = 0; i < table.Rows.Count; i++)
            {
                cboUsername.Items.Add(table.Rows[i][9].ToString());
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            //Open Login form
            this.Hide();
            Login ss = new Login();
            ss.Show();
        }

        private void btnResetPass_Click(object sender, EventArgs e)
        {
            try
            {
                //Resets password to the default: "Password1"
                using (SqlCommand cmd = new SqlCommand("UPDATE Staff SET Password=@Password WHERE Username=@Username", cn))
                {
                    cmd.Parameters.AddWithValue("@Username", cboUsername.Text);

                    //Encrypts the entered password
                    string ePass = EncryptPass.ComputeHash(password, "SHA512", null);
                    cmd.Parameters.AddWithValue("@Password", ePass);
                    cmd.ExecuteNonQuery();
                }

                //Retrieves the Email from the Staff table
                SqlCommand command = new SqlCommand("SELECT Email FROM Staff WHERE Username = @Username", cn);
                command.Parameters.AddWithValue("@Username", cboUsername.Text);
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        Email = ((string.Format("{0}", reader["Email"])));

                    }
                }

                //Sends Email using the Gmail server
                MailMessage mail = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");

                mail.From = new MailAddress("thequinnhotel@gmail.com");
                mail.To.Add(Email);
                mail.Subject = "The Quinn Hotel Password Reset " + DateTime.Now;
                mail.Body = "Your account password has been set to: Password1";

                SmtpServer.Port = 587;
                SmtpServer.Credentials = new System.Net.NetworkCredential("thequinnhotel", "Cactus123");
                SmtpServer.EnableSsl = true;

                SmtpServer.Send(mail);
                MessageBox.Show("Email has been sent to your registered email address.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
