﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using MetroFramework.Forms;

namespace Hotel_Booking_System
{
    public partial class CheckIn : MetroForm
    {
        public static int CheckInValue = 0;

        SqlConnection cn = new SqlConnection("server=Laptop-PC\\SQLEXPRESS; database=HotelBookingDB ;Trusted_Connection=True");

        public CheckIn()
        {
            InitializeComponent();

        }

        private void CheckIn_Load(object sender, EventArgs e)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = new SqlConnection(Properties.Resources.HotelBookingDBConnectionString);
            command.CommandText = "SELECT * FROM Booking WHERE StartDate = @Datenow AND CheckIn = 0";
            command.Parameters.Add("@Datenow", SqlDbType.Date).Value = DateTime.Today;

            //The data adapter fills the data set with data from the Rooms table
            SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
            dataAdapter.Fill(this.hotelBookingDBBookCheckInDataSet.Booking);
        }

        private void btnCheckIn_Click(object sender, EventArgs e)
        {
            //Identifies the selected row
            int indexOfSelectedRow = metroGrid1.CurrentCell.RowIndex;
            int BookingID = Convert.ToInt32(metroGrid1.Rows[indexOfSelectedRow].Cells[0].Value);

            //Loads the DataGridView according to the parameters
            string constring = Properties.Resources.HotelBookingDBConnectionString;
            string sqlUpdate = "UPDATE Booking SET CheckIn = '1'  WHERE BookingID = '" + BookingID + "'";
            SqlConnection conDatabase = new SqlConnection(constring);
            SqlCommand cmd = new SqlCommand(sqlUpdate, conDatabase);
            conDatabase.Open();
            cmd.ExecuteNonQuery();
            conDatabase.Close();

            MessageBox.Show("Check In Succesful.");
            
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            //Refreshes the form
            metroGrid1.DataSource = null;
            metroGrid1.Update();
            metroGrid1.Refresh();

            SqlCommand command = new SqlCommand();
            command.Connection = new SqlConnection(Properties.Resources.HotelBookingDBConnectionString);
            command.CommandText = "SELECT * FROM Booking WHERE StartDate = @Datenow AND CheckIn = 0";
            command.Parameters.Add("@Datenow", SqlDbType.Date).Value = DateTime.Today;

            //The data adapter fills the data set with data from the Rooms table
            SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
            dataAdapter.Fill(this.hotelBookingDBBookCheckInDataSet.Booking);

            MessageBox.Show("Refreshed.");
            
        }

    }
}
